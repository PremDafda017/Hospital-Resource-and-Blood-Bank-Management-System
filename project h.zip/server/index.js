const dns = require("dns");
dns.setServers(["8.8.8.8", "8.8.4.4"]);
dns.setDefaultResultOrder("ipv4first");

const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");
require("dotenv").config({ path: "../.env" });

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB connection
const mongoUri = process.env.MONGODB_URI;
console.log("Connecting to MongoDB URI:", mongoUri);

// Configure Mongoose to fail fast instead of buffering when disconnected
mongoose.set("bufferCommands", false);

mongoose
  .connect(mongoUri, {
    serverSelectionTimeoutMS: 3000, // Timeout after 3 seconds instead of 10+
  })
  .then(() => console.log("MongoDB connected successfully."))
  .catch((err) => {
    console.error("MongoDB connection error:", err.message);
    console.warn("Continuing server execution with Mock JSON Database fallback.");
  });

// Generate custom 7-character lowercase alphanumeric ID (e.g. "lx15b16")
const generateCustomId = () => {
  return Math.random().toString(36).substring(2, 9);
};

// User Profile Schema for MongoDB
const userProfileSchema = new mongoose.Schema(
  {
    _id: { type: String, default: generateCustomId },
    clerkId: { type: String, required: true, unique: true },
    fullName: { type: String, required: true },
    email: { type: String, required: true },
    role: { type: String, required: true },
    isVerified: { type: Boolean, default: true },
  },
  { timestamps: true }
);

const UserProfile = mongoose.model("UserProfile", userProfileSchema);

// Local JSON file mock database fallback setup
const mockDbPath = path.join(__dirname, "mockDb.json");

const getMockProfiles = () => {
  if (!fs.existsSync(mockDbPath)) {
    fs.writeFileSync(mockDbPath, JSON.stringify([], null, 2));
  }
  try {
    return JSON.parse(fs.readFileSync(mockDbPath, "utf8"));
  } catch (err) {
    return [];
  }
};

const saveMockProfile = (profileData) => {
  const profiles = getMockProfiles();
  const index = profiles.findIndex((p) => p.clerkId === profileData.clerkId);
  const now = new Date().toISOString();
  let updatedProfile;

  if (index !== -1) {
    updatedProfile = {
      ...profiles[index],
      fullName: profileData.fullName,
      email: profileData.email,
      role: profileData.role,
      isVerified: true,
      updatedAt: now,
    };
    profiles[index] = updatedProfile;
  } else {
    updatedProfile = {
      _id: generateCustomId(),
      clerkId: profileData.clerkId,
      fullName: profileData.fullName,
      email: profileData.email,
      role: profileData.role,
      isVerified: true,
      createdAt: now,
      updatedAt: now,
    };
    profiles.push(updatedProfile);
  }

  fs.writeFileSync(mockDbPath, JSON.stringify(profiles, null, 2));
  return updatedProfile;
};

// Create or update user profile route
app.post("/api/users/create-profile", async (req, res) => {
  const { clerkId, fullName, email, role } = req.body;

  if (!clerkId || !fullName || !email || !role) {
    return res.status(400).json({ message: "clerkId, fullName, email, and role are required." });
  }

  const isDbConnected = mongoose.connection.readyState === 1;

  if (isDbConnected) {
    try {
      // Check if profile already exists for this clerkId
      let profile = await UserProfile.findOne({ clerkId });

      if (profile) {
        // Update existing profile
        profile.fullName = fullName;
        profile.email = email;
        profile.role = role;
        profile.isVerified = true;
        await profile.save();
        console.log(`[MongoDB] Updated profile for Clerk ID: ${clerkId}`);
        return res.status(200).json({ message: "Profile updated successfully.", profile });
      }

      // Create new profile with custom ID
      const customId = generateCustomId();
      profile = new UserProfile({
        _id: customId,
        clerkId,
        fullName,
        email,
        role,
        isVerified: true
      });

      await profile.save();
      console.log(`[MongoDB] Created profile in database:`, profile);
      res.status(201).json({ message: "Profile created successfully in database.", profile });
    } catch (err) {
      console.error("Create profile error:", err);
      res.status(500).json({ message: "Server error occurred while creating profile." });
    }
  } else {
    // Fallback to Mock Database
    try {
      const profile = saveMockProfile({ clerkId, fullName, email, role });
      console.log(`[MockDB] Saved profile (MongoDB offline):`, profile);
      res.status(201).json({
        message: "Profile saved successfully in Mock local database (MongoDB connection not active).",
        profile,
      });
    } catch (err) {
      console.error("Mock save profile error:", err);
      res.status(500).json({ message: "Server error saving to mock database." });
    }
  }
});

// Check profile in MongoDB by clerkId
app.get("/api/users/profile/:clerkId", async (req, res) => {
  const { clerkId } = req.params;
  const isDbConnected = mongoose.connection.readyState === 1;

  if (isDbConnected) {
    try {
      const profile = await UserProfile.findOne({ clerkId });
      if (!profile) {
        return res.status(404).json({ message: "Profile not found in database." });
      }
      res.status(200).json(profile);
    } catch (err) {
      console.error("Get profile error:", err);
      res.status(500).json({ message: "Server error occurred while retrieving profile." });
    }
  } else {
    // Fallback to Mock Database
    const profiles = getMockProfiles();
    const profile = profiles.find((p) => p.clerkId === clerkId);
    if (!profile) {
      return res.status(404).json({ message: "Profile not found in Mock database." });
    }
    res.status(200).json(profile);
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
