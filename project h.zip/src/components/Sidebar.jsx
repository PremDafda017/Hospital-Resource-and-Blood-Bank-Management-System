import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  FaChartLine,
  FaUsers,
  FaUserDoctor,
  FaHandHoldingMedical,
  FaDroplet,
  FaHeartPulse,
  FaCalendarDays,
  FaClipboardList,
  FaGear,
  FaRightFromBracket,
  FaBuilding,
  FaChartBar,
  FaBell
} from 'react-icons/fa6';
import './styles/Sidebar.css';

function Sidebar({ isOpen, onClose }) {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { path: '/dashboard', icon: <FaChartLine />, label: 'Dashboard' },
    { path: '/patients', icon: <FaUsers />, label: 'Patients' },
    { path: '/doctors', icon: <FaUserDoctor />, label: 'Doctors' },
    { path: '/donors', icon: <FaHandHoldingMedical />, label: 'Donors' },
    { path: '/blood-inventory', icon: <FaDroplet />, label: 'Blood Inventory' },
    { path: '/blood-requests', icon: <FaHeartPulse />, label: 'Blood Requests' },
    { path: '/blood-banks', icon: <FaBuilding />, label: 'Blood Banks' },
    { path: '/appointments', icon: <FaCalendarDays />, label: 'Appointments' },
    { path: '/reports', icon: <FaClipboardList />, label: 'Reports' },
    { path: '/analytics', icon: <FaChartBar />, label: 'Analytics' },
    { path: '/notifications', icon: <FaBell />, label: 'Notifications' },
    { path: '/settings', icon: <FaGear />, label: 'Settings' },
  ];

  const handleNavigation = (path) => {
    navigate(path);
    if (onClose) onClose();
  };

  const handleLogout = () => {
    // This will be handled by the parent component or auth context
    if (onClose) onClose();
    navigate('/login');
  };

  return (
    <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <span className="sidebar-logo-icon">
            <FaDroplet />
          </span>
          <span>HRBMS</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        <ul>
          {menuItems.map((item) => (
            <li
              key={item.path}
              className={`sidebar-nav-item ${location.pathname === item.path ? 'active' : ''}`}
              onClick={() => handleNavigation(item.path)}
            >
              {item.icon}
              <span>{item.label}</span>
            </li>
          ))}
        </ul>
      </nav>

      <div className="sidebar-footer">
        <div className="sidebar-footer-item" onClick={handleLogout}>
          <FaRightFromBracket />
          <span>Sign Out</span>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;