import React from 'react';
import './Loader.css';

function Loader({ size = 'medium', text = 'Loading...' }) {
  return (
    <div className={`loader-container loader-${size}`}>
      <div className="loader-spinner"></div>
      {text && <p className="loader-text">{text}</p>}
    </div>
  );
}

export default Loader;