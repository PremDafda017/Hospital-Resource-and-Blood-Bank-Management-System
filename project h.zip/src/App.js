import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import React from "react";
import { useAuth } from "@clerk/clerk-react";

import Login from "./pages/Login";
import Register from "./pages/Register";
import VerifyOTP from "./pages/VerifyOTP";
import HomePage from "./pages/HomePage";
import Dashboard from "./pages/Dashboard";
import BloodInventory from "./pages/BloodInventory/BloodInventory";
import AddStock from "./pages/BloodInventory/AddStock";
import StockHistory from "./pages/BloodInventory/StockHistory";

// Patients
import Patients from "./pages/Patients/Patients";
import AddPatient from "./pages/Patients/AddPatient";
import PatientDetails from "./pages/Patients/PatientDetails";

// Doctors
import Doctors from "./pages/Doctors/Doctors";
import AddDoctor from "./pages/Doctors/AddDoctor";
import DoctorDetails from "./pages/Doctors/DoctorDetails";

// Donors
import Donors from "./pages/Donors/Donors";
import AddDonor from "./pages/Donors/AddDonor";
import DonorDetails from "./pages/Donors/DonorDetails";

// Blood Banks
import BloodBanks from "./pages/BloodBanks/BloodBanks";
import BloodBankDetails from "./pages/BloodBanks/BloodBankDetails";
import BloodBankMap from "./pages/BloodBanks/BloodBankMap";

// Blood Requests
import BloodRequests from "./pages/BloodRequests/BloodRequests";
import CreateRequest from "./pages/BloodRequests/CreateRequest";
import RequestDetails from "./pages/BloodRequests/RequestDetails";

// Appointments
import Appointments from "./pages/Appointments/Appointments";
import AddAppointment from "./pages/Appointments/AddAppointment";

// Reports
import Reports from "./pages/Reports/Reports";
import BloodReport from "./pages/Reports/BloodReport";
import PatientReport from "./pages/Reports/PatientReport";

// Analytics
import Analytics from "./pages/Analytics/Analytics";
import BloodPrediction from "./pages/Analytics/BloodPrediction";
import Charts from "./pages/Analytics/Charts";

// Notifications
import Notifications from "./pages/Notifications/Notifications";

// Settings
import Settings from "./pages/Settings/Settings";

// Premium Clinical Global Loader
const GlobalLoader = () => (
  <div style={{
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    backgroundColor: "#060B16",
    color: "#F4F7FD",
    fontFamily: "'Inter', sans-serif"
  }}>
    <div style={{
      position: "relative",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      marginBottom: "20px"
    }}>
      <div style={{
        position: "absolute",
        width: "70px",
        height: "70px",
        borderRadius: "50%",
        border: "3px solid #FB7185",
        opacity: 0.3,
        animation: "pulseRing 1.8s cubic-bezier(0.215, 0.610, 0.355, 1) infinite"
      }} />
      <div style={{
        width: "48px",
        height: "48px",
        borderRadius: "50%",
        border: "3px solid transparent",
        borderTopColor: "#FB7185",
        borderRightColor: "#FB7185",
        animation: "spin 1s linear infinite"
      }} />
      <div style={{
        position: "absolute",
        width: "16px",
        height: "16px",
        borderRadius: "50%",
        backgroundColor: "#FB7185",
        boxShadow: "0 0 15px #FB7185"
      }} />
    </div>
    
    <h3 style={{
      fontSize: "15px",
      fontWeight: 600,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: "#9AABC9",
      margin: "0 0 8px 0"
    }}>
      HRBMS Secure Console
    </h3>
    <p style={{
      fontSize: "13px",
      color: "#64748B",
      margin: 0
    }}>
      Initializing session authorization...
    </p>

    <style>{`
      @keyframes pulseRing {
        0% { transform: scale(0.65); opacity: 0.8; }
        100% { transform: scale(1.3); opacity: 0; }
      }
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `}</style>
  </div>
);

// Protected Route Component (Requires Clerk Sign In)
const ProtectedRoute = ({ children }) => {
  const { isSignedIn, isLoaded } = useAuth();
  
  if (!isLoaded) {
    return <GlobalLoader />;
  }
  
  if (!isSignedIn) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
};

// Public Route Component (redirects to home if logged in)
const PublicRoute = ({ children }) => {
  const { isSignedIn, isLoaded } = useAuth();
  
  if (!isLoaded) {
    return <GlobalLoader />;
  }
  
  if (isSignedIn) {
    return <Navigate to="/" replace />;
  }
  
  return children;
};



function App() {
  return (
    <Router>
      <Routes>
        {/* Default Route - Home Page (Public) */}
        <Route path="/" element={<HomePage />} />

        {/* Authentication */}
        <Route
          path="/login"
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          }
        />
        <Route
          path="/register"
          element={
            <PublicRoute>
              <Register />
            </PublicRoute>
          }
        />
        <Route
          path="/verify-otp"
          element={
            <PublicRoute>
              <VerifyOTP />
            </PublicRoute>
          }
        />

        {/* Dashboard */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        {/* Blood Inventory */}
        <Route
          path="/blood-inventory"
          element={
            <ProtectedRoute>
              <BloodInventory />
            </ProtectedRoute>
          }
        />
        <Route
          path="/blood-inventory/add"
          element={
            <ProtectedRoute>
              <AddStock />
            </ProtectedRoute>
          }
        />
        <Route
          path="/blood-inventory/history"
          element={
            <ProtectedRoute>
              <StockHistory />
            </ProtectedRoute>
          }
        />

        {/* Patients */}
        <Route
          path="/patients"
          element={
            <ProtectedRoute>
              <Patients />
            </ProtectedRoute>
          }
        />
        <Route
          path="/patients/add"
          element={
            <ProtectedRoute>
              <AddPatient />
            </ProtectedRoute>
          }
        />
        <Route
          path="/patients/:id"
          element={
            <ProtectedRoute>
              <PatientDetails />
            </ProtectedRoute>
          }
        />
        <Route
          path="/patients/:id/edit"
          element={
            <ProtectedRoute>
              <AddPatient />
            </ProtectedRoute>
          }
        />

        {/* Doctors */}
        <Route
          path="/doctors"
          element={
            <ProtectedRoute>
              <Doctors />
            </ProtectedRoute>
          }
        />
        <Route
          path="/doctors/add"
          element={
            <ProtectedRoute>
              <AddDoctor />
            </ProtectedRoute>
          }
        />
        <Route
          path="/doctors/:id"
          element={
            <ProtectedRoute>
              <DoctorDetails />
            </ProtectedRoute>
          }
        />
        <Route
          path="/doctors/:id/edit"
          element={
            <ProtectedRoute>
              <AddDoctor />
            </ProtectedRoute>
          }
        />

        {/* Donors */}
        <Route
          path="/donors"
          element={
            <ProtectedRoute>
              <Donors />
            </ProtectedRoute>
          }
        />
        <Route
          path="/donors/add"
          element={
            <ProtectedRoute>
              <AddDonor />
            </ProtectedRoute>
          }
        />
        <Route
          path="/donors/:id"
          element={
            <ProtectedRoute>
              <DonorDetails />
            </ProtectedRoute>
          }
        />
        <Route
          path="/donors/:id/edit"
          element={
            <ProtectedRoute>
              <AddDonor />
            </ProtectedRoute>
          }
        />

        {/* Blood Banks */}
        <Route
          path="/blood-banks"
          element={
            <ProtectedRoute>
              <BloodBanks />
            </ProtectedRoute>
          }
        />
        <Route
          path="/blood-banks/:id"
          element={
            <ProtectedRoute>
              <BloodBankDetails />
            </ProtectedRoute>
          }
        />
        <Route
          path="/blood-banks/:id/edit"
          element={
            <ProtectedRoute>
              <BloodBanks />
            </ProtectedRoute>
          }
        />
        <Route
          path="/blood-banks/map"
          element={
            <ProtectedRoute>
              <BloodBankMap />
            </ProtectedRoute>
          }
        />

        {/* Blood Requests */}
        <Route
          path="/blood-requests"
          element={
            <ProtectedRoute>
              <BloodRequests />
            </ProtectedRoute>
          }
        />
        <Route
          path="/blood-requests/create"
          element={
            <ProtectedRoute>
              <CreateRequest />
            </ProtectedRoute>
          }
        />
        <Route
          path="/blood-requests/:id"
          element={
            <ProtectedRoute>
              <RequestDetails />
            </ProtectedRoute>
          }
        />

        {/* Appointments */}
        <Route
          path="/appointments"
          element={
            <ProtectedRoute>
              <Appointments />
            </ProtectedRoute>
          }
        />
        <Route
          path="/appointments/add"
          element={
            <ProtectedRoute>
              <AddAppointment />
            </ProtectedRoute>
          }
        />

        {/* Reports */}
        <Route
          path="/reports"
          element={
            <ProtectedRoute>
              <Reports />
            </ProtectedRoute>
          }
        />
        <Route
          path="/reports/:id"
          element={
            <ProtectedRoute>
              <BloodReport />
            </ProtectedRoute>
          }
        />
        <Route
          path="/reports/patient/:id"
          element={
            <ProtectedRoute>
              <PatientReport />
            </ProtectedRoute>
          }
        />

        {/* Analytics */}
        <Route
          path="/analytics"
          element={
            <ProtectedRoute>
              <Analytics />
            </ProtectedRoute>
          }
        />
        <Route
          path="/analytics/prediction"
          element={
            <ProtectedRoute>
              <BloodPrediction />
            </ProtectedRoute>
          }
        />
        <Route
          path="/analytics/charts"
          element={
            <ProtectedRoute>
              <Charts />
            </ProtectedRoute>
          }
        />

        {/* Notifications */}
        <Route
          path="/notifications"
          element={
            <ProtectedRoute>
              <Notifications />
            </ProtectedRoute>
          }
        />

        {/* Settings */}
        <Route
          path="/settings"
          element={
            <ProtectedRoute>
              <Settings />
            </ProtectedRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;