import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  FaArrowLeft,
  FaUser,
  FaPhone,
  FaEnvelope,
  FaDroplet,
  FaCalendar,
  FaNotesMedical,
  FaHospital,
  FaPencil,
  FaPrint,
  FaFileMedical
} from 'react-icons/fa6';
import DashboardLayout from '../../components/DashboardLayout';
import './Patients.css';

function PatientDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [patient, setPatient] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPatientDetails = async () => {
      try {
        const storedPatients = localStorage.getItem('patients');
        let foundPatient = null;
        if (storedPatients) {
          const patientsList = JSON.parse(storedPatients);
          foundPatient = patientsList.find(p => String(p.id) === String(id));
        }

        setTimeout(() => {
          if (foundPatient) {
            // split name into first and last if needed
            const nameParts = foundPatient.name ? foundPatient.name.split(' ') : ['User', ''];
            setPatient({
              ...foundPatient,
              firstName: foundPatient.firstName || nameParts[0],
              lastName: foundPatient.lastName || nameParts.slice(1).join(' '),
            });
          } else {
            // Mock data fallback
            const mockPatient = {
              id: id,
              firstName: 'John',
              lastName: 'Smith',
              dateOfBirth: '1979-05-15',
              gender: 'Male',
              bloodType: 'A+',
              phone: '555-0101',
              email: 'john.smith@email.com',
              address: '123 Main St, City, State 12345',
              emergencyContact: 'Jane Smith',
              emergencyPhone: '555-0102',
              medicalHistory: 'Hypertension, Type 2 Diabetes',
              allergies: 'Penicillin',
              currentCondition: 'Critical',
              admissionDate: '2024-01-15',
              assignedDoctor: 'Dr. Sarah Johnson',
              roomNumber: 'ICU-301',
              insuranceProvider: 'Blue Cross',
              insuranceNumber: 'BC123456789',
              status: 'Active'
            };
            setPatient(mockPatient);
          }
          setLoading(false);
        }, 500);
      } catch (error) {
        console.error('Error fetching patient details:', error);
        setLoading(false);
      }
    };
    fetchPatientDetails();
  }, [id]);

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <DashboardLayout title="Patient Files" subtitle="Verifying clinical dossier..." activeTab="/patients">
        <div className="page-loading" style={{ minHeight: '300px' }}>
          <span className="btn-spinner" />
          <p>Loading patient records…</p>
        </div>
      </DashboardLayout>
    );
  }

  if (!patient) {
    return (
      <DashboardLayout title="Patient Files" subtitle="Operational Console" activeTab="/patients">
        <div className="empty-state">
          <h3>Patient record not found</h3>
          <button 
            className="btn-primary"
            onClick={() => navigate('/patients')}
          >
            Back to Patients
          </button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Patient Profile Details" subtitle={`Viewing record for ${patient.firstName} ${patient.lastName}`} activeTab="/patients">
      <div className="patient-details-page">
        <div className="page-header" style={{ marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <button 
            className="btn-outline"
            onClick={() => navigate('/patients')}
          >
            <FaArrowLeft /> Back to Patients
          </button>
          <div className="header-actions">
            <button className="btn-outline" onClick={handlePrint}>
              <FaPrint /> Print
            </button>
            <button 
              className="btn-secondary"
              onClick={() => navigate(`/patients/${id}/edit`)}
            >
              <FaPencil /> Edit
            </button>
          </div>
        </div>

        <div className="patient-details-container">
          {/* Patient Header Card */}
          <div className="detail-card patient-header-card">
            <div className="patient-avatar-large">
              {patient.firstName[0] || ''}{patient.lastName[0] || ''}
            </div>
            <div className="patient-header-info">
              <h2>{patient.firstName} {patient.lastName}</h2>
              <div className="patient-meta-tags">
                <span className="badge badge-info">{patient.bloodType}</span>
                <span className="badge badge-success">{patient.status}</span>
                <span className="badge badge-warning">{patient.currentCondition || patient.condition}</span>
              </div>
              <div className="patient-basic-info">
                <span><FaCalendar /> DOB: {patient.dateOfBirth || 'N/A'}</span>
                <span><FaUser /> {patient.gender || 'N/A'}</span>
                <span><FaDroplet /> Blood Type: {patient.bloodType}</span>
              </div>
            </div>
          </div>

          {/* Personal Information */}
          <div className="detail-card">
            <h3><FaUser /> Personal Information</h3>
            <div className="detail-grid">
              <div className="detail-row">
                <label>Full Name</label>
                <span>{patient.firstName} {patient.lastName}</span>
              </div>
              <div className="detail-row">
                <label>Date of Birth</label>
                <span>{patient.dateOfBirth || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <label>Gender</label>
                <span>{patient.gender || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <label>Blood Type</label>
                <span>{patient.bloodType}</span>
              </div>
              <div className="detail-row">
                <label>Phone</label>
                <span><FaPhone /> {patient.phone}</span>
              </div>
              <div className="detail-row">
                <label>Email</label>
                <span><FaEnvelope /> {patient.email || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <label>Address</label>
                <span>{patient.address || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Emergency Contact */}
          <div className="detail-card">
            <h3><FaPhone /> Emergency Contact</h3>
            <div className="detail-grid">
              <div className="detail-row">
                <label>Contact Name</label>
                <span>{patient.emergencyContact || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <label>Contact Phone</label>
                <span><FaPhone /> {patient.emergencyPhone || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Medical Information */}
          <div className="detail-card">
            <h3><FaNotesMedical /> Medical Information</h3>
            <div className="detail-grid">
              <div className="detail-row">
                <label>Medical History</label>
                <span>{patient.medicalHistory || 'None recorded'}</span>
              </div>
              <div className="detail-row">
                <label>Allergies</label>
                <span className="allergies">{patient.allergies || 'No known allergies'}</span>
              </div>
              <div className="detail-row">
                <label>Current Condition</label>
                <span className="condition">{patient.currentCondition || patient.condition}</span>
              </div>
              <div className="detail-row">
                <label>Admission Date</label>
                <span><FaCalendar /> {patient.admissionDate}</span>
              </div>
            </div>
          </div>

          {/* Hospital Details */}
          <div className="detail-card">
            <h3><FaHospital /> Hospital Details</h3>
            <div className="detail-grid">
              <div className="detail-row">
                <label>Assigned Doctor</label>
                <span>{patient.assignedDoctor || 'Unassigned'}</span>
              </div>
              <div className="detail-row">
                <label>Room Number</label>
                <span>{patient.roomNumber || 'Outpatient'}</span>
              </div>
              <div className="detail-row">
                <label>Insurance Provider</label>
                <span>{patient.insuranceProvider || 'None'}</span>
              </div>
              <div className="detail-row">
                <label>Insurance Number</label>
                <span>{patient.insuranceNumber || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="detail-card">
            <h3><FaFileMedical /> Quick Actions</h3>
            <div className="quick-actions">
              <button className="btn-secondary">
                <FaFileMedical /> View Medical Records
              </button>
              <button className="btn-secondary" onClick={() => navigate('/blood-requests/create')}>
                <FaDroplet /> Request Blood
              </button>
              <button className="btn-secondary">
                <FaCalendar /> Schedule Appointment
              </button>
              <button className="btn-secondary">
                <FaHospital /> Transfer Patient
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

export default PatientDetails;