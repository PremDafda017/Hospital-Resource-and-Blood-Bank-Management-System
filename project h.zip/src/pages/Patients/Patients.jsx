import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaUsers,
  FaPlus,
  FaMagnifyingGlass,
  FaFilter,
  FaPencil,
  FaEye,
  FaTrash,
  FaCalendar,
  FaDroplet,
  FaPhone,
  FaEnvelope
} from 'react-icons/fa6';
import DashboardLayout from '../../components/DashboardLayout';

/* Design Tokens matching Dashboard */
const FONT = "'Inter','Segoe UI',system-ui,sans-serif";
const RED = "#C41230";
const RED_DARK = "#8B0000";
const RED_GLOW = "rgba(196,18,48,0.15)";
const SLATE = "#1E293B";
const SLATE_MD = "#334155";
const SLATE_LT = "#64748B";
const SMOKE = "#F8FAFC";
const WHITE = "#FFFFFF";
const BORDER = "#E2E8F0";

const BG_COLOR = {
  "A+":"#16A34A","A-":"#15803D","B+":"#2563EB","B-":"#1D4ED8",
  "AB+":"#7C3AED","AB-":"#6D28D9","O+":RED,"O-":RED_DARK
};

function StatusPill({ status }) {
  const colors = {
    "Active": { bg:"rgba(22,163,74,0.12)", text:"#16A34A" },
    "Discharged": { bg:"rgba(245,158,11,0.12)", text:"#F59E0B" },
    "Deceased": { bg:"rgba(239,68,68,0.12)", text:"#EF4444" },
  };
  const c = colors[status] || { bg:SMOKE, text:SLATE_LT };
  return (
    <span style={{ background:c.bg, color:c.text, fontWeight:700, fontSize:"0.72rem", padding:"4px 10px", borderRadius:12, whiteSpace:"nowrap" }}>
      {status}
    </span>
  );
}

function Patients() {
  const navigate = useNavigate();
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = async () => {
    try {
      const storedPatients = localStorage.getItem('patients');

      setTimeout(() => {
        if (storedPatients) {
          setPatients(JSON.parse(storedPatients));
        } else {
          const mockPatients = [
            {
              id: 1,
              name: 'John Smith',
              age: 45,
              bloodType: 'A+',
              condition: 'Critical',
              phone: '555-0101',
              email: 'john.smith@email.com',
              admissionDate: '2024-01-15',
              status: 'Active'
            },
            {
              id: 2,
              name: 'Sarah Johnson',
              age: 32,
              bloodType: 'O-',
              condition: 'Stable',
              phone: '555-0102',
              email: 'sarah.j@email.com',
              admissionDate: '2024-01-18',
              status: 'Active'
            },
            {
              id: 3,
              name: 'Michael Brown',
              age: 58,
              bloodType: 'B+',
              condition: 'Recovering',
              phone: '555-0103',
              email: 'm.brown@email.com',
              admissionDate: '2024-01-20',
              status: 'Discharged'
            }
          ];

          localStorage.setItem('patients', JSON.stringify(mockPatients));
          setPatients(mockPatients);
        }

        setLoading(false);
      }, 500);
    } catch (error) {
      console.error('Error fetching patients:', error);
      setLoading(false);
    }
  };

  const filteredPatients = patients.filter(patient => {
    const matchesSearch = patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || patient.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getConditionColor = (condition) => {
    switch (condition.toLowerCase()) {
      case 'critical': return RED;
      case 'stable': return '#16A34A';
      case 'recovering': return '#F59E0B';
      default: return SLATE_LT;
    }
  };

  return (
    <DashboardLayout activeTab="patients" title="Patients Operations" subtitle="Manage clinical logs, admissions, and status updates">
      {/* Header Actions */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:28 }}>
        <div>
          <h2 style={{ fontFamily:FONT, fontWeight:800, fontSize:"1.3rem", color:SLATE, marginBottom:4 }}>Clinical Patient Registry</h2>
          <p style={{ color:SLATE_LT, fontSize:"0.85rem" }}>{filteredPatients.length} patients in system</p>
        </div>
        <button 
          onClick={() => navigate('/patients/add')}
          style={{
            background:RED, color:WHITE, border:"none", borderRadius:12,
            padding:"12px 24px", fontFamily:FONT, fontSize:"0.9rem", fontWeight:700,
            cursor:"pointer", display:"flex", alignItems:"center", gap:10,
            transition:"all 0.25s", boxShadow:`0 4px 14px ${RED_GLOW}`
          }}
          onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = `0 6px 20px ${RED_GLOW}`; }}
          onMouseLeave={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = `0 4px 14px ${RED_GLOW}`; }}
        >
          <FaPlus /> Add Patient
        </button>
      </div>

      {/* Filters */}
      <div style={{ display:"flex", gap:12, marginBottom:24 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, background:WHITE, border:`1px solid ${BORDER}`, borderRadius:14, padding:"10px 16px", flex:1, maxWidth:400 }}>
          <FaMagnifyingGlass style={{ color:SLATE_LT, fontSize:"0.95rem" }}/>
          <input
            type="text"
            placeholder="Search patients by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ border:"none", background:"transparent", fontFamily:FONT, fontSize:"0.9rem", color:SLATE, outline:"none", width:"100%" }}
          />
        </div>

        <div style={{ display:"flex", alignItems:"center", gap:10, background:WHITE, border:`1px solid ${BORDER}`, borderRadius:14, padding:"10px 16px" }}>
          <FaFilter style={{ color:SLATE_LT, fontSize:"0.95rem" }}/>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            style={{ border:"none", background:"transparent", fontFamily:FONT, fontSize:"0.9rem", color:SLATE, outline:"none", cursor:"pointer" }}
          >
            <option value="all">All Status</option>
            <option value="Active">Active</option>
            <option value="Discharged">Discharged</option>
            <option value="Deceased">Deceased</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", minHeight:300, gap:12 }}>
          <div style={{ width:48, height:48, borderRadius:"50%", border:`3px solid ${BORDER}`, borderTopColor:RED, animation:"spin 0.9s linear infinite" }}/>
          <style>{"@keyframes spin{to{transform:rotate(360deg)}}"}</style>
          <p style={{ color:SLATE_LT, fontWeight:600 }}>Loading patients…</p>
        </div>
      ) : (
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))", gap:20 }}>
          {filteredPatients.length > 0 ? (
            filteredPatients.map(patient => (
              <div key={patient.id} style={{
                background:WHITE, borderRadius:20, border:`1px solid ${BORDER}`,
                padding:"24px", boxShadow:"0 4px 20px rgba(0,0,0,0.06)",
                transition:"all 0.3s", cursor:"pointer"
              }}
                onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = "0 12px 32px rgba(0,0,0,0.1)"; }}
                onMouseLeave={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 20px rgba(0,0,0,0.06)"; }}
              >
                {/* Header */}
                <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:18 }}>
                  <div style={{ 
                    width:52, height:52, borderRadius:14, 
                    background:`linear-gradient(135deg,${RED},${RED_DARK})`, 
                    display:"flex", alignItems:"center", justifyContent:"center", 
                    color:WHITE, fontWeight:800, fontSize:"1.2rem" 
                  }}>
                    {patient.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div style={{ flex:1 }}>
                    <h3 style={{ fontFamily:FONT, fontWeight:800, fontSize:"1.05rem", color:SLATE, marginBottom:6 }}>{patient.name}</h3>
                    <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                      <StatusPill status={patient.status} />
                      <span style={{ color:getConditionColor(patient.condition), fontWeight:700, fontSize:"0.72rem", padding:"4px 10px", borderRadius:12, background:`rgba(${parseInt(getConditionColor(patient.condition).slice(1,3),16)},${parseInt(getConditionColor(patient.condition).slice(3,5),16)},${parseInt(getConditionColor(patient.condition).slice(5,7),16)},0.12)` }}>
                        {patient.condition}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div style={{ display:"flex", flexDirection:"column", gap:10, marginBottom:18 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10, color:SLATE_LT, fontSize:"0.85rem" }}>
                    <FaDroplet style={{ color:SLATE_MD }}/>
                    <span>Blood Type: <strong style={{ color:SLATE }}>{patient.bloodType}</strong></span>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:10, color:SLATE_LT, fontSize:"0.85rem" }}>
                    <FaCalendar style={{ color:SLATE_MD }}/>
                    <span>Age: <strong style={{ color:SLATE }}>{patient.age}</strong></span>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:10, color:SLATE_LT, fontSize:"0.85rem" }}>
                    <FaPhone style={{ color:SLATE_MD }}/>
                    <span>{patient.phone}</span>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:10, color:SLATE_LT, fontSize:"0.85rem" }}>
                    <FaEnvelope style={{ color:SLATE_MD }}/>
                    <span>{patient.email}</span>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:10, color:SLATE_LT, fontSize:"0.85rem" }}>
                    <FaCalendar style={{ color:SLATE_MD }}/>
                    <span>Admitted: {patient.admissionDate}</span>
                  </div>
                </div>

                {/* Actions */}
                <div style={{ display:"flex", gap:10, paddingTop:16, borderTop:`1px solid ${BORDER}` }}>
                  <button 
                    onClick={() => navigate(`/patients/${patient.id}`)}
                    style={{
                      flex:1, background:SMOKE, color:SLATE, border:`1px solid ${BORDER}`, borderRadius:10,
                      padding:"10px 16px", fontFamily:FONT, fontSize:"0.85rem", fontWeight:600,
                      cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:8,
                      transition:"all 0.2s"
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = BORDER; }}
                    onMouseLeave={e => { e.currentTarget.style.background = SMOKE; }}
                  >
                    <FaEye /> View
                  </button>
                  <button 
                    onClick={() => navigate(`/patients/${patient.id}/edit`)}
                    style={{
                      flex:1, background:SMOKE, color:SLATE, border:`1px solid ${BORDER}`, borderRadius:10,
                      padding:"10px 16px", fontFamily:FONT, fontSize:"0.85rem", fontWeight:600,
                      cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:8,
                      transition:"all 0.2s"
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = BORDER; }}
                    onMouseLeave={e => { e.currentTarget.style.background = SMOKE; }}
                  >
                    <FaPencil /> Edit
                  </button>
                  <button 
                    onClick={() => {
                      const updated = patients.filter(p => p.id !== patient.id);
                      setPatients(updated);
                      localStorage.setItem('patients', JSON.stringify(updated));
                    }}
                    style={{
                      background:"rgba(239,68,68,0.12)", color:"#EF4444", border:"none", borderRadius:10,
                      padding:"10px 16px", fontFamily:FONT, fontSize:"0.85rem", fontWeight:600,
                      cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:8,
                      transition:"all 0.2s"
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = "rgba(239,68,68,0.2)"; }}
                    onMouseLeave={e => { e.currentTarget.style.background = "rgba(239,68,68,0.12)"; }}
                  >
                    <FaTrash />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div style={{ gridColumn:"1 / -1", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", minHeight:300, gap:16 }}>
              <div style={{ width:80, height:80, borderRadius:20, background:SMOKE, display:"flex", alignItems:"center", justifyContent:"center", color:SLATE_LT, fontSize:"2.5rem" }}>
                <FaUsers />
              </div>
              <h3 style={{ fontFamily:FONT, fontWeight:800, fontSize:"1.2rem", color:SLATE }}>No patients found</h3>
              <p style={{ color:SLATE_LT, fontSize:"0.9rem" }}>Try adjusting your search or filter criteria</p>
            </div>
          )}
        </div>
      )}
    </DashboardLayout>
  );
}

export default Patients;