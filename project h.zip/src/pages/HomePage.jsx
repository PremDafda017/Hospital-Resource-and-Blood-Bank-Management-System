import React, { useState, useEffect, useRef } from "react";
import { useAuth, useUser } from "@clerk/clerk-react";
import { useNavigate } from "react-router-dom";
import {
    FaRightFromBracket,
    FaDroplet,
    FaChartLine,
    FaUsers,
    FaUserDoctor,
    FaHandHoldingMedical,
    FaHeartPulse,
    FaCalendarDays,
    FaClipboardList,
    FaGear,
    FaBars,
    FaMagnifyingGlass,
    FaBell,
    FaSun,
    FaMoon,
    FaHospital
} from "react-icons/fa6";

/* ─────────────────────────────────────────────
   INLINE STYLES (no external CSS required)
   Palette: Crimson #C41230 · Deep #8B0000 · Slate #1E293B
            Smoke #F8FAFC · Mist #EFF6FF · Pure #FFFFFF
   Type: Inter (system-stack fallback)
───────────────────────────────────────────── */

const FONT = "'Inter','Segoe UI',system-ui,sans-serif";
const RED      = "#C41230";
const RED_DARK = "#8B0000";
const RED_GLOW = "rgba(196,18,48,0.15)";
const SLATE    = "#1E293B";
const SLATE_MD = "#334155";
const SLATE_LT = "#64748B";
const SMOKE    = "#F8FAFC";
const WHITE    = "#FFFFFF";
const BORDER   = "#E2E8F0";

// ── Animated Counter ──────────────────────────────────────────────────────────
function Counter({ target, suffix = "" }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let start = 0;
          const step = Math.ceil(target / 60);
          const timer = setInterval(() => {
            start += step;
            if (start >= target) { setCount(target); clearInterval(timer); }
            else setCount(start);
          }, 25);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);
  return <span ref={ref}>{count.toLocaleString()}{suffix}</span>;
}

// ── Blood Group Badge ─────────────────────────────────────────────────────────
const BG_COLOR = { "A+":"#16A34A","A-":"#15803D","B+":"#2563EB","B-":"#1D4ED8","AB+":"#7C3AED","AB-":"#6D28D9","O+":RED,"O-":RED_DARK };

// ── Section Wrapper ───────────────────────────────────────────────────────────
function Section({ children, bg = WHITE, id }) {
  return (
    <section id={id} style={{ background:bg, padding:"96px 0", position:"relative" }}>
      <div style={{ maxWidth:1200, margin:"0 auto", padding:"0 24px" }}>{children}</div>
    </section>
  );
}

function SectionLabel({ text }) {
  return (
    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
      <div style={{ width:32, height:3, background:`linear-gradient(90deg,${RED},${RED_DARK})`, borderRadius:2 }}/>
      <span style={{ color:RED, fontWeight:700, fontSize:"0.8rem", textTransform:"uppercase", letterSpacing:"0.1em" }}>{text}</span>
    </div>
  );
}

function SectionTitle({ children, light = false }) {
  return (
    <h2 style={{ fontFamily:FONT, fontSize:"clamp(2rem,4vw,2.8rem)", fontWeight:800, color:light?WHITE:SLATE, lineHeight:1.15, marginBottom:16 }}>
      {children}
    </h2>
  );
}

// ── Card ──────────────────────────────────────────────────────────────────────
function Card({ children, style = {}, hover = true }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onMouseEnter={() => hover && setHovered(true)}
      onMouseLeave={() => hover && setHovered(false)}
      style={{
        background:WHITE, borderRadius:20, border:`1px solid ${BORDER}`,
        padding:"28px 28px", boxShadow: hovered ? "0 20px 60px rgba(0,0,0,0.12)" : "0 4px 20px rgba(0,0,0,0.06)",
        transition:"all 0.3s cubic-bezier(.4,0,.2,1)",
        transform: hovered ? "translateY(-6px)" : "translateY(0)",
        ...style
      }}
    >
      {children}
    </div>
  );
}

// ── Input ─────────────────────────────────────────────────────────────────────
function Input({ placeholder, type = "text", style = {} }) {
  const [focused, setFocused] = useState(false);
  return (
    <input
      type={type}
      placeholder={placeholder}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      style={{
        width:"100%", padding:"14px 18px", borderRadius:12, border:`2px solid ${focused ? RED : BORDER}`,
        fontFamily:FONT, fontSize:"0.95rem", color:SLATE, outline:"none", background:WHITE,
        transition:"border-color 0.2s", boxSizing:"border-box", ...style
      }}
    />
  );
}

function Select({ options, style = {} }) {
  const [focused, setFocused] = useState(false);
  return (
    <select
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      style={{
        width:"100%", padding:"14px 18px", borderRadius:12, border:`2px solid ${focused ? RED : BORDER}`,
        fontFamily:FONT, fontSize:"0.95rem", color:SLATE, outline:"none", background:WHITE,
        transition:"border-color 0.2s", boxSizing:"border-box", appearance:"none", cursor:"pointer", ...style
      }}
    >
      {options.map(o => <option key={o}>{o}</option>)}
    </select>
  );
}

function PrimaryBtn({ children, style = {}, onClick }) {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? `linear-gradient(135deg,${RED_DARK},${RED})` : `linear-gradient(135deg,${RED},${RED_DARK})`,
        color:WHITE, border:"none", borderRadius:12, padding:"14px 28px", fontFamily:FONT,
        fontSize:"0.95rem", fontWeight:700, cursor:"pointer",
        boxShadow: hovered ? `0 12px 32px ${RED_GLOW}` : `0 4px 16px ${RED_GLOW}`,
        transform: hovered ? "translateY(-2px)" : "translateY(0)",
        transition:"all 0.25s cubic-bezier(.4,0,.2,1)", whiteSpace:"nowrap", ...style
      }}
    >
      {children}
    </button>
  );
}

function GhostBtn({ children, style = {}, onClick, dark = false }) {
  const [hovered, setHovered] = useState(false);
  const base = dark ? "rgba(255,255,255,0.12)" : "transparent";
  const hov  = dark ? "rgba(255,255,255,0.2)" : SMOKE;
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? hov : base,
        color: dark ? WHITE : SLATE, border:`2px solid ${dark?"rgba(255,255,255,0.3)":BORDER}`,
        borderRadius:12, padding:"13px 28px", fontFamily:FONT, fontSize:"0.95rem",
        fontWeight:600, cursor:"pointer",
        transform: hovered ? "translateY(-2px)" : "translateY(0)",
        transition:"all 0.25s", whiteSpace:"nowrap", ...style
      }}
    >
      {children}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export default function HomePage() {
  const { isSignedIn, signOut } = useAuth();
  const { user } = useUser();
  const navigate = useNavigate();
  const [navScrolled, setNavScrolled] = useState(false);
  const [step, setStep] = useState(1);
  const [userProfile, setUserProfile] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [theme, setTheme] = useState(() => localStorage.getItem("dashboard-theme") || "light");

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    localStorage.setItem("dashboard-theme", newTheme);
  };

  useEffect(() => {
    const onScroll = () => setNavScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (isSignedIn) {
      const fullName = localStorage.getItem("userFullName") || user?.fullName || "";
      const email = localStorage.getItem("userEmail") || user?.primaryEmailAddress?.emailAddress || "";
      const role = localStorage.getItem("userRole") || "donor";
      setUserProfile({ fullName, email, role });
    } else {
      setUserProfile(null);
    }
  }, [isSignedIn, user]);

  const handleLoginClick = () => {
    navigate("/login");
  };

  const handleLogout = async () => {
    await signOut();
    localStorage.removeItem("userFullName");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("userRole");
    navigate("/");
  };

  const handleProtectedAction = () => {
    if (!isSignedIn) {
      alert("Please login first to access this feature.");
      navigate("/login");
    }
  };

  const navItems = [
    { key:"home",           icon:<FaChartLine/>,        label:"Home"           },
    { key:"blood-search",   icon:<FaMagnifyingGlass/>,  label:"Blood Search"   },
    { key:"donate",         icon:<FaHandHoldingMedical/>,label:"Donate"         },
    { key:"hospitals",      icon:<FaHospital/>,         label:"Hospitals"      },
  ];

  const loggedInNavItems = [
    { key:"dashboard",      icon:<FaChartLine/>,        label:"Dashboard"      },
  ];

  const initials = user?.firstName ? `${user.firstName[0]}${user.lastName?.[0]||""}` : "U";
  const displayName = userProfile?.fullName || user?.fullName || "User";
  const displayRole = userProfile?.role || "donor";

  return (
    <div style={{ fontFamily:FONT, color:SLATE, overflowX:"hidden" }}>

      {/* ── Global CSS ── */}
      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body { background: ${WHITE}; }
        input::placeholder { color: ${SLATE_LT}; }
        @keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:.5;} }
        @keyframes float { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-12px);} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(24px);} to{opacity:1;transform:translateY(0);} }
        @keyframes shimmer { 0%{background-position:-200% center;} 100%{background-position:200% center;} }
        .animate-fade-up { animation: fadeUp 0.7s cubic-bezier(.4,0,.2,1) both; }
        .animate-float { animation: float 4s ease-in-out infinite; }
        @media(max-width:768px){
          .hero-buttons{flex-direction:column!important;align-items:stretch!important;}
          .hero-stats{flex-wrap:wrap!important;gap:16px!important;}
          .two-col{grid-template-columns:1fr!important;}
          .three-col{grid-template-columns:1fr!important;}
          .four-col{grid-template-columns:1fr 1fr!important;}
        }
        @media(max-width:480px){
          .four-col{grid-template-columns:1fr!important;}
        }
      `}</style>

      {/* ════════════════════════════════════════════════
          NAV (Dashboard-style)
      ════════════════════════════════════════════════ */}
      <nav style={{
        position:"fixed", top:0, left:0, right:0, zIndex:1000,
        background: navScrolled ? "rgba(255,255,255,0.97)" : "transparent",
        backdropFilter: navScrolled ? "blur(20px)" : "none",
        borderBottom: navScrolled ? `1px solid ${BORDER}` : "none",
        boxShadow: navScrolled ? "0 4px 30px rgba(0,0,0,0.08)" : "none",
        transition:"all 0.4s cubic-bezier(.4,0,.2,1)",
        padding:"0 24px"
      }}>
        <div style={{ maxWidth:1200, margin:"0 auto", display:"flex", alignItems:"center", justifyContent:"space-between", height:72 }}>
          {/* Logo */}
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <div style={{ 
                width:40, height:40, borderRadius:12, 
                background:`linear-gradient(135deg,${RED},${RED_DARK})`, 
                display:"flex", alignItems:"center", justifyContent:"center", 
                color:WHITE, fontSize:"1.2rem" 
            }}>
                <FaDroplet/>
            </div>
            <span style={{ fontWeight:900, fontSize:"1.25rem", color: navScrolled ? SLATE : WHITE, letterSpacing:"-0.02em", transition:"color 0.3s" }}>
              Hemo<span style={{ color:RED }}>Care</span>
            </span>
          </div>

          {/* Desktop Nav Links */}
          <div style={{ display:"flex", gap:8, alignItems:"center" }} className="desktop-nav">
            {navItems.map(({ key, icon, label }) => (
                <a key={key} href={`#${key}`}
                    style={{
                        display:"flex", alignItems:"center", gap:8,
                        padding:"10px 16px", borderRadius:12,
                        color: navScrolled ? SLATE_MD : "rgba(255,255,255,0.85)",
                        fontWeight:500, fontSize:"0.9rem",
                        textDecoration:"none", transition:"all 0.2s"
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = navScrolled ? SMOKE : "rgba(255,255,255,0.1)"; e.currentTarget.style.color = RED; }}
                    onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = navScrolled ? SLATE_MD : "rgba(255,255,255,0.85)"; }}
                >
                    <span style={{ fontSize:"1rem" }}>{icon}</span>
                    <span>{label}</span>
                </a>
            ))}
            {/* Dashboard link - only show when logged in */}
            {isSignedIn && userProfile && loggedInNavItems.map(({ key, icon, label }) => (
                <a key={key} onClick={() => navigate(`/${key}`)}
                    style={{
                        display:"flex", alignItems:"center", gap:8,
                        padding:"10px 16px", borderRadius:12,
                        color: navScrolled ? SLATE_MD : "rgba(255,255,255,0.85)",
                        fontWeight:500, fontSize:"0.9rem",
                        textDecoration:"none", transition:"-all 0.2s", cursor:"pointer"
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = navScrolled ? SMOKE : "rgba(255,255,255,0.1)"; e.currentTarget.style.color = RED; }}
                    onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = navScrolled ? SLATE_MD : "rgba(255,255,255,0.85)"; }}
                >
                    <span style={{ fontSize:"1rem" }}>{icon}</span>
                    <span>{label}</span>
                </a>
            ))}
          </div>

          {/* Right Actions */}
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            {/* Search */}
            <div style={{ display:"flex", alignItems:"center", gap:10, background:navScrolled ? SMOKE : "rgba(255,255,255,0.1)", border:navScrolled ? `1px solid ${BORDER}` : "1px solid rgba(255,255,255,0.2)", borderRadius:14, padding:"10px 16px", transition:"all 0.25s" }}>
                <FaMagnifyingGlass style={{ color:navScrolled ? SLATE_LT : "rgba(255,255,255,0.7)", fontSize:"0.95rem" }}/>
                <input placeholder="Search..." style={{ border:"none", background:"transparent", fontFamily:FONT, fontSize:"0.9rem", color:navScrolled ? SLATE : WHITE, outline:"none", width:100 }}/>
            </div>

            {/* Theme Toggle */}
            <button onClick={toggleTheme} style={{ width:42, height:42, borderRadius:12, border:navScrolled ? `1px solid ${BORDER}` : "1px solid rgba(255,255,255,0.2)", background:navScrolled ? SMOKE : "rgba(255,255,255,0.1)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:navScrolled ? SLATE_MD : "rgba(255,255,255,0.85)", fontSize:"1rem", transition:"all 0.25s" }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = RED; e.currentTarget.style.color = RED; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = navScrolled ? BORDER : "rgba(255,255,255,0.2)"; e.currentTarget.style.color = navScrolled ? SLATE_MD : "rgba(255,255,255,0.85)"; }}
            >
                {theme === "dark" ? <FaSun/> : <FaMoon/>}
            </button>

            {/* Notification */}
            <button style={{ width:42, height:42, borderRadius:12, border:navScrolled ? `1px solid ${BORDER}` : "1px solid rgba(255,255,255,0.2)", background:navScrolled ? SMOKE : "rgba(255,255,255,0.1)", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:navScrolled ? SLATE_MD : "rgba(255,255,255,0.85)", fontSize:"1rem", position:"relative", transition:"all 0.25s" }}
                onMouseEnter={e => e.currentTarget.style.borderColor = RED}
                onMouseLeave={e => e.currentTarget.style.borderColor = navScrolled ? BORDER : "rgba(255,255,255,0.2)"}
            >
                <FaBell/>
                <span style={{ position:"absolute", top:-2, right:-2, background:RED, color:WHITE, fontSize:"0.65rem", fontWeight:800, minWidth:18, height:18, borderRadius:9, display:"flex", alignItems:"center", justifyContent:"center" }}>3</span>
            </button>

            {/* Auth Buttons or Profile */}
            {isSignedIn && userProfile ? (
                <div style={{ position:"relative" }}>
                    <button onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                        style={{ width:42, height:42, borderRadius:12, background:`linear-gradient(135deg,${RED},${RED_DARK})`, border:"none", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:WHITE, fontWeight:800, fontSize:"0.95rem", transition:"all 0.25s" }}
                        onMouseEnter={e => e.currentTarget.style.transform = "scale(1.05)"}
                        onMouseLeave={e => e.currentTarget.style.transform = "scale(1)"}
                    >
                        {initials}
                    </button>
                    {profileDropdownOpen && (
                        <div style={{ position:"absolute", right:0, top:52, width:300, background:WHITE, border:`1px solid ${BORDER}`, borderRadius:18, boxShadow:"0 20px 60px rgba(0,0,0,0.15)", zIndex:300, overflow:"hidden" }}>
                            <div style={{ padding:"20px 22px", borderBottom:`1px solid ${BORDER}`, background:SMOKE }}>
                                <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:14 }}>
                                    <div style={{ width:48, height:48, borderRadius:14, background:`linear-gradient(135deg,${RED},${RED_DARK})`, display:"flex", alignItems:"center", justifyContent:"center", color:WHITE, fontWeight:800, fontSize:"1.2rem" }}>
                                        {initials}
                                    </div>
                                    <div style={{ flex:1 }}>
                                        <p style={{ fontWeight:800, color:SLATE, fontSize:"1rem", lineHeight:1.2 }}>{displayName}</p>
                                        <span style={{ background:RED_GLOW, color:RED, fontWeight:700, fontSize:"0.72rem", padding:"4px 12px", borderRadius:14, marginTop:6, display:"inline-block", textTransform:"capitalize" }}>{displayRole.replace("_"," ")}</span>
                                    </div>
                                </div>
                                <p style={{ color:SLATE_LT, fontSize:"0.85rem", marginTop:10, wordBreak:"break-all" }}>{userProfile.email || user?.primaryEmailAddress?.emailAddress}</p>
                            </div>
                            
                            <div style={{ padding:"10px 0" }}>
                                <div onClick={() => navigate("/dashboard")} style={{ padding:"16px 22px", cursor:"pointer", color:SLATE, fontSize:"0.9rem", fontWeight:500, display:"flex", alignItems:"center", gap:12, transition:"background 0.15s" }}
                                    onMouseEnter={e => e.currentTarget.style.background = SMOKE}
                                    onMouseLeave={e => e.currentTarget.style.background = WHITE}
                                >📊 Dashboard</div>
                                <div onClick={() => navigate("/settings")} style={{ padding:"16px 22px", cursor:"pointer", color:SLATE, fontSize:"0.9rem", fontWeight:500, display:"flex", alignItems:"center", gap:12, transition:"background 0.15s" }}
                                    onMouseEnter={e => e.currentTarget.style.background = SMOKE}
                                    onMouseLeave={e => e.currentTarget.style.background = WHITE}
                                >⚙️ Settings</div>
                            </div>
                            
                            <div style={{ borderTop:`1px solid ${BORDER}`, padding:"14px 22px" }}>
                                <div onClick={handleLogout} style={{ color:RED, fontWeight:700, fontSize:"0.9rem", cursor:"pointer", display:"flex", alignItems:"center", gap:10 }}>
                                    <FaRightFromBracket /> Logout
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            ) : (
                <>
                    <GhostBtn dark={!navScrolled} onClick={handleLoginClick} style={{ padding:"10px 20px", fontSize:"0.88rem" }}>Log In</GhostBtn>
                    <PrimaryBtn onClick={handleProtectedAction} style={{ padding:"10px 20px", fontSize:"0.88rem" }}>Donate Now</PrimaryBtn>
                </>
            )}
          </div>
        </div>
      </nav>

      {/* ════════════════════════════════════════════════
          HERO
      ════════════════════════════════════════════════ */}
      <header id="home" style={{
        minHeight:"100vh", position:"relative", display:"flex", alignItems:"center",
        background:`linear-gradient(135deg, ${RED_DARK} 0%, #3B0000 40%, #1E293B 100%)`,
        overflow:"hidden"
      }}>
        {/* Background pattern */}
        <div style={{ position:"absolute", inset:0, opacity:0.06 }}
          dangerouslySetInnerHTML={{__html:`<svg width="60" height="60" xmlns="http://www.w3.org/2000/svg"><path d="M30 5 C30 5 20 20 20 28 C20 36 24 40 30 40 C36 40 40 36 40 28 C40 20 30 5 30 5Z" fill="white"/></svg>`}}
        />
        {/* Decorative blobs */}
        <div style={{ position:"absolute", top:-100, right:-100, width:600, height:600, borderRadius:"50%", background:"radial-gradient(circle,rgba(196,18,48,0.3) 0%,transparent 70%)" }}/>
        <div style={{ position:"absolute", bottom:-150, left:-100, width:500, height:500, borderRadius:"50%", background:"radial-gradient(circle,rgba(139,0,0,0.25) 0%,transparent 70%)" }}/>

        {/* Floating blood drop decorations */}
        <div className="animate-float" style={{ position:"absolute", right:"8%", top:"20%", fontSize:"6rem", opacity:0.12 }}>🩸</div>
        <div className="animate-float" style={{ position:"absolute", right:"18%", bottom:"25%", fontSize:"4rem", opacity:0.08, animationDelay:"1.5s" }}>🩸</div>

        <div style={{ maxWidth:1200, margin:"0 auto", padding:"0 24px", width:"100%", paddingTop:96 }}>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:64, alignItems:"center" }} className="two-col">

            {/* Left */}
            <div className="animate-fade-up">
              {isSignedIn && userProfile && (
                <div style={{ background:"rgba(255,255,255,0.15)", backdropFilter:"blur(12px)", border:"1px solid rgba(255,255,255,0.25)", borderRadius:16, padding:"16px 20px", marginBottom:24 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                    <div style={{ width:48, height:48, borderRadius:12, background:`linear-gradient(135deg,${RED},${RED_DARK})`, display:"flex", alignItems:"center", justifyContent:"center", color:WHITE, fontWeight:800, fontSize:"1.2rem" }}>
                      {userProfile.fullName?.charAt(0)?.toUpperCase() || "U"}
                    </div>
                    <div style={{ flex:1 }}>
                      <p style={{ color:WHITE, fontWeight:800, fontSize:"1rem", lineHeight:1.2 }}>{userProfile.fullName || "User"}</p>
                      <p style={{ color:"rgba(255,255,255,0.75)", fontSize:"0.8rem", marginTop:2 }}>{userProfile.email || ""}</p>
                      <span style={{ background:RED, color:WHITE, fontWeight:700, fontSize:"0.7rem", padding:"2px 10px", borderRadius:12, marginTop:4, display:"inline-block", textTransform:"capitalize" }}>{userProfile.role?.replace("_"," ") || "Donor"}</span>
                    </div>
                  </div>
                </div>
              )}

              <div style={{ display:"inline-flex", alignItems:"center", gap:8, background:"rgba(255,255,255,0.12)", backdropFilter:"blur(8px)", border:"1px solid rgba(255,255,255,0.2)", borderRadius:40, padding:"6px 16px", marginBottom:24 }}>
                <span style={{ width:8, height:8, borderRadius:"50%", background:"#4ADE80", boxShadow:"0 0 0 3px rgba(74,222,128,0.3)", animation:"pulse 2s infinite" }}/>
                <span style={{ color:"rgba(255,255,255,0.9)", fontSize:"0.8rem", fontWeight:600 }}>Live: 3 Emergency Requests Active</span>
              </div>

              <h1 style={{ fontFamily:FONT, fontSize:"clamp(2.8rem,6vw,4.5rem)", fontWeight:900, color:WHITE, lineHeight:1.05, letterSpacing:"-0.03em", marginBottom:24 }}>
                Donate Blood,<br/>
                <span style={{ background:`linear-gradient(90deg,#FCA5A5,#FECACA)`, WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>Save Lives</span>
              </h1>

              <p style={{ color:"rgba(255,255,255,0.7)", fontSize:"1.1rem", lineHeight:1.7, marginBottom:36, maxWidth:480 }}>
                Every donation matters. Connect with blood banks, find donors, and manage emergency requests — all in one trusted platform used by 200+ hospitals.
              </p>

              <div className="hero-buttons" style={{ display:"flex", gap:12, marginBottom:48 }}>
                <PrimaryBtn onClick={handleProtectedAction} style={{ padding:"16px 36px", fontSize:"1rem", borderRadius:14 }}>🩸 Donate Now</PrimaryBtn>
                <GhostBtn dark onClick={handleProtectedAction} style={{ padding:"16px 36px", fontSize:"1rem", borderRadius:14 }}>🔍 Find Blood</GhostBtn>
              </div>

              {/* Mini stats */}
              <div className="hero-stats" style={{ display:"flex", gap:32, borderTop:"1px solid rgba(255,255,255,0.15)", paddingTop:28 }}>
                {[["48K+","Registered Donors"],["12K+","Lives Saved"],["200+","Partner Hospitals"]].map(([n,l]) => (
                  <div key={l}>
                    <div style={{ color:WHITE, fontWeight:800, fontSize:"1.6rem", lineHeight:1 }}>{n}</div>
                    <div style={{ color:"rgba(255,255,255,0.55)", fontSize:"0.8rem", marginTop:4 }}>{l}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right – Glassmorphism panel */}
            <div style={{ display:"flex", justifyContent:"center" }}>
              <div className="animate-float" style={{
                background:"rgba(255,255,255,0.1)", backdropFilter:"blur(20px)",
                border:"1px solid rgba(255,255,255,0.2)", borderRadius:28,
                padding:32, width:"100%", maxWidth:380,
                boxShadow:"0 32px 80px rgba(0,0,0,0.3)"
              }}>
                <div style={{ fontWeight:800, color:WHITE, fontSize:"1.05rem", marginBottom:20, display:"flex", alignItems:"center", gap:8 }}>
                  <span>🏥</span> Blood Availability
                </div>
                {[["O+","124 units","Available"],["A+","89 units","Available"],["B+","42 units","Low"],["AB-","8 units","Critical"],["O-","5 units","Critical"]].map(([g,u,s]) => {
                  const sc = s==="Critical"?RED:s==="Low"?"#F59E0B":"#22C55E";
                  return (
                    <div key={g} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 14px", background:"rgba(255,255,255,0.08)", borderRadius:10, marginBottom:6, border:"1px solid rgba(255,255,255,0.1)" }}>
                      <span style={{ background:BG_COLOR[g]||RED, color:WHITE, fontWeight:700, fontSize:"0.78rem", padding:"3px 9px", borderRadius:16 }}>{g}</span>
                      <span style={{ color:"rgba(255,255,255,0.8)", fontWeight:600, fontSize:"0.85rem" }}>{u}</span>
                      <span style={{ color:sc, fontWeight:700, fontSize:"0.75rem" }}>{s}</span>
                    </div>
                  );
                })}
                <PrimaryBtn onClick={handleProtectedAction} style={{ width:"100%", marginTop:16, borderRadius:12, justifyContent:"center", display:"block" }}>Check Full Availability</PrimaryBtn>
              </div>
            </div>

          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{ position:"absolute", bottom:32, left:"50%", transform:"translateX(-50%)", display:"flex", flexDirection:"column", alignItems:"center", gap:6 }}>
          <span style={{ color:"rgba(255,255,255,0.4)", fontSize:"0.75rem", letterSpacing:"0.1em" }}>SCROLL</span>
          <div style={{ width:1, height:36, background:"rgba(255,255,255,0.2)", borderRadius:1 }}/>
        </div>
      </header>

      {/* ════════════════════════════════════════════════
          STATS STRIP
      ════════════════════════════════════════════════ */}
      <div style={{ background:SLATE, padding:"48px 24px" }}>
        <div style={{ maxWidth:1200, margin:"0 auto", display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:0 }} className="four-col">
          {[
            ["🧑‍🤝‍🧑","48,250","Registered Donors"],
            ["🩸","12,840","Blood Units Available"],
            ["❤️","12,300","Lives Saved"],
            ["🏥","214","Partner Hospitals"]
          ].map(([icon,target,label],i) => (
            <div key={label} style={{ textAlign:"center", padding:"24px 16px", borderRight: i<3 ? "1px solid rgba(255,255,255,0.08)" : "none" }}>
              <div style={{ fontSize:"2rem", marginBottom:8 }}>{icon}</div>
              <div style={{ fontFamily:FONT, fontWeight:900, fontSize:"2.2rem", color:WHITE, lineHeight:1 }}>
                <Counter target={parseInt(target.replace(/,/g,""))} suffix={target.includes("+")?"+":""} />
              </div>
              <div style={{ color:"rgba(255,255,255,0.5)", fontSize:"0.83rem", marginTop:6, fontWeight:500 }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ════════════════════════════════════════════════
          BLOOD SEARCH
      ════════════════════════════════════════════════ */}
      <Section bg={SMOKE} id="blood-search">
        <SectionLabel text="Blood Availability" />
        <SectionTitle>Find Blood Near You</SectionTitle>
        <p style={{ color:SLATE_LT, fontSize:"1rem", lineHeight:1.7, marginBottom:48, maxWidth:520 }}>
          Search our real-time database across all blood groups and locations to find available units when you need them most.
        </p>

        {/* Search Bar */}
        <div style={{ background:WHITE, borderRadius:20, padding:24, boxShadow:"0 8px 40px rgba(0,0,0,0.08)", border:`1px solid ${BORDER}`, marginBottom:40, display:"grid", gridTemplateColumns:"1fr 1fr auto", gap:16, alignItems:"end" }} className="search-bar">
          <style>{`.search-bar{grid-template-columns:1fr 1fr auto!important;} @media(max-width:640px){.search-bar{grid-template-columns:1fr!important;}}`}</style>
          <div>
            <label style={{ display:"block", fontWeight:600, fontSize:"0.85rem", color:SLATE_MD, marginBottom:8 }}>Blood Group</label>
            <Select options={["All Blood Groups","A+","A-","B+","B-","AB+","AB-","O+","O-"]} />
          </div>
          <div>
            <label style={{ display:"block", fontWeight:600, fontSize:"0.85rem", color:SLATE_MD, marginBottom:8 }}>City / Location</label>
            <Input placeholder="Enter city or pincode…" />
          </div>
          <PrimaryBtn onClick={handleProtectedAction} style={{ height:50, padding:"0 32px", borderRadius:12 }}>🔍 Search</PrimaryBtn>
        </div>

        {/* Results Grid */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:16 }} className="four-col">
          {[["A+","89","Available",82],["B+","42","Low",38],["O+","124","Available",95],["AB+","67","Available",60],["A-","31","Low",28],["B-","15","Low",12],["O-","5","Critical",5],["AB-","8","Critical",7]].map(([g,u,s,pct]) => {
            const sc = s==="Critical"?RED:s==="Low"?"#D97706":"#16A34A";
            return (
              <Card key={g} style={{ textAlign:"center", padding:"24px 20px" }}>
                <div style={{ width:56, height:56, borderRadius:16, background:BG_COLOR[g]||RED, display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 12px", boxShadow:`0 8px 20px ${BG_COLOR[g]||RED}40` }}>
                  <span style={{ color:WHITE, fontWeight:900, fontSize:"1rem" }}>{g}</span>
                </div>
                <div style={{ fontWeight:800, fontSize:"1.8rem", color:SLATE, lineHeight:1 }}>{u}</div>
                <div style={{ color:SLATE_LT, fontSize:"0.8rem", marginTop:2, marginBottom:10 }}>units available</div>
                <div style={{ height:6, background:BORDER, borderRadius:3, marginBottom:10 }}>
                  <div style={{ height:"100%", width:`${pct}%`, background:sc, borderRadius:3, transition:"width 1s ease" }}/>
                </div>
                <span style={{ color:sc, fontWeight:700, fontSize:"0.78rem", background:`${sc}15`, padding:"3px 10px", borderRadius:16 }}>{s}</span>
              </Card>
            );
          })}
        </div>
      </Section>

      {/* ════════════════════════════════════════════════
          EMERGENCY REQUEST
      ════════════════════════════════════════════════ */}
      <section style={{ background:`linear-gradient(135deg,${RED_DARK},${RED})`, padding:"80px 24px", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", top:-60, right:-60, width:300, height:300, borderRadius:"50%", background:"rgba(255,255,255,0.05)" }}/>
        <div style={{ position:"absolute", bottom:-80, left:-40, width:250, height:250, borderRadius:"50%", background:"rgba(255,255,255,0.04)" }}/>
        <div style={{ maxWidth:900, margin:"0 auto", position:"relative" }}>

          {/* Urgent Banner */}
          <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:10, background:"rgba(255,255,255,0.15)", borderRadius:12, padding:"12px 24px", marginBottom:36, backdropFilter:"blur(8px)", border:"1px solid rgba(255,255,255,0.2)" }}>
            <span style={{ animation:"pulse 1.5s infinite", fontSize:"1.2rem" }}>🚨</span>
            <span style={{ color:WHITE, fontWeight:700, fontSize:"0.95rem" }}>EMERGENCY REQUEST — Response within 30 minutes guaranteed</span>
          </div>

          <SectionTitle light>Emergency Blood Request</SectionTitle>
          <p style={{ color:"rgba(255,255,255,0.75)", marginBottom:36, fontSize:"0.95rem" }}>Fill this form and our team will match you with available donors and hospitals immediately.</p>

          <div style={{ background:"rgba(255,255,255,0.1)", backdropFilter:"blur(20px)", border:"1px solid rgba(255,255,255,0.2)", borderRadius:24, padding:36 }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, marginBottom:20 }} className="two-col">
              <Input placeholder="Patient Full Name" style={{ background:"rgba(255,255,255,0.95)" }} />
              <Input placeholder="Contact Number" type="tel" style={{ background:"rgba(255,255,255,0.95)" }} />
              <Select options={["Blood Group Required","A+","A-","B+","B-","AB+","AB-","O+","O-"]} style={{ background:"rgba(255,255,255,0.95)" }} />
              <Input placeholder="Hospital Name" style={{ background:"rgba(255,255,255,0.95)" }} />
              <Input placeholder="Units Required" type="number" style={{ background:"rgba(255,255,255,0.95)" }} />
              <Input placeholder="City / Location" style={{ background:"rgba(255,255,255,0.95)" }} />
            </div>
            <textarea placeholder="Additional information (optional)…" style={{ width:"100%", padding:"14px 18px", borderRadius:12, border:`2px solid ${BORDER}`, fontFamily:FONT, fontSize:"0.95rem", color:SLATE, outline:"none", background:"rgba(255,255,255,0.95)", resize:"vertical", minHeight:80, boxSizing:"border-box", marginBottom:20 }} />
            <button onClick={handleProtectedAction} style={{ width:"100%", background:WHITE, color:RED, border:"none", borderRadius:12, padding:"16px", fontFamily:FONT, fontSize:"1rem", fontWeight:800, cursor:"pointer", transition:"all 0.2s", boxShadow:"0 8px 24px rgba(0,0,0,0.2)" }}
              onMouseEnter={e => { e.target.style.background = "#FFF5F5"; e.target.style.transform = "translateY(-2px)"; }}
              onMouseLeave={e => { e.target.style.background = WHITE; e.target.style.transform = "translateY(0)"; }}
            >🚨 Submit Emergency Request</button>
          </div>
        </div>
      </section>

      {/* ════════════════════════════════════════════════
          DONOR REGISTRATION (multi-step)
      ════════════════════════════════════════════════ */}
      <Section bg={WHITE} id="donate">
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:64, alignItems:"start" }} className="two-col">
          <div>
            <SectionLabel text="Become a Donor" />
            <SectionTitle>Register as a Blood Donor</SectionTitle>
            <p style={{ color:SLATE_LT, fontSize:"0.95rem", lineHeight:1.7, marginBottom:32 }}>
              Joining takes less than 5 minutes. One donation can save up to 3 lives. Your blood group, health, and schedule — we handle the rest.
            </p>
            {[["Why donate?","One unit of blood can save up to 3 lives. Donors also receive free health screenings."],["Who can donate?","Anyone aged 18–65, weighing 50kg+, in general good health can donate every 56 days."],["What to expect?","Registration → Health check → Donation (8–10 min) → Refreshments → Certificate"]].map(([t,d]) => (
              <div key={t} style={{ display:"flex", gap:14, marginBottom:20 }}>
                <div style={{ width:8, height:8, borderRadius:"50%", background:RED, flexShrink:0, marginTop:7 }}/>
                <div>
                  <div style={{ fontWeight:700, color:SLATE, marginBottom:3 }}>{t}</div>
                  <div style={{ color:SLATE_LT, fontSize:"0.88rem", lineHeight:1.6 }}>{d}</div>
                </div>
              </div>
            ))}
          </div>

          <Card style={{ padding:36 }} hover={false}>
            {/* Step progress */}
            <div style={{ display:"flex", alignItems:"center", gap:0, marginBottom:32 }}>
              {[1,2,3].map((s,i) => (
                <React.Fragment key={s}>
                  <div style={{ width:32, height:32, borderRadius:"50%", background: step>=s ? RED : BORDER, color: step>=s ? WHITE : SLATE_LT, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:"0.85rem", transition:"all 0.3s", flexShrink:0 }}>{s}</div>
                  {i<2 && <div style={{ flex:1, height:2, background: step>s+1 ? RED : BORDER, transition:"background 0.3s" }}/>}
                </React.Fragment>
              ))}
            </div>
            <div style={{ fontWeight:700, fontSize:"0.8rem", color:SLATE_LT, marginBottom:20, letterSpacing:"0.05em" }}>
              {step===1?"PERSONAL INFO":step===2?"HEALTH DETAILS":"SCHEDULE"}
            </div>

            {step===1 && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                  <Input placeholder="First Name" />
                  <Input placeholder="Last Name" />
                </div>
                <Input placeholder="Email Address" type="email" />
                <Input placeholder="Phone Number" type="tel" />
                <Input placeholder="Date of Birth" type="date" />
              </div>
            )}
            {step===2 && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <Select options={["Select Blood Group","A+","A-","B+","B-","AB+","AB-","O+","O-"]} />
                <Input placeholder="Weight (kg)" type="number" />
                <Select options={["Last Donation","Never donated","Within 3 months","Within 6 months","Over 6 months ago"]} />
                <Select options={["Any medical conditions?","None","Diabetes","Hypertension","Other"]} />
              </div>
            )}
            {step===3 && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                <Input placeholder="Preferred Date" type="date" />
                <Select options={["Preferred Time","Morning (9 AM–12 PM)","Afternoon (12–4 PM)","Evening (4–7 PM)"]} />
                <Select options={["Preferred Location","City Blood Bank","Apollo Hospital","Fortis Healthcare","AIIMS"]} />
                <Input placeholder="City" />
              </div>
            )}

            <div style={{ display:"flex", justifyContent:"space-between", marginTop:24 }}>
              {step>1 ? <GhostBtn onClick={() => setStep(s=>s-1)} style={{ flex:1, marginRight:10 }}>← Back</GhostBtn> : <div/>}
              {step<3
                ? <PrimaryBtn onClick={handleProtectedAction} style={{ flex:1 }}>Next →</PrimaryBtn>
                : <PrimaryBtn onClick={handleProtectedAction} style={{ flex:1 }}>✓ Register Donor</PrimaryBtn>
              }
            </div>
          </Card>
        </div>
      </Section>

      {/* ════════════════════════════════════════════════
          DONATION PROCESS
      ════════════════════════════════════════════════ */}
      <Section bg={SMOKE} id="process">
        <div style={{ textAlign:"center", marginBottom:60 }}>
          <SectionLabel text="How It Works" />
          <SectionTitle>Simple 4-Step Process</SectionTitle>
          <p style={{ color:SLATE_LT, maxWidth:480, margin:"0 auto", fontSize:"0.95rem", lineHeight:1.7 }}>From registration to saving a life — the entire process takes under 90 minutes.</p>
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:24, position:"relative" }} className="four-col">
          {/* Connector line */}
          <div style={{ position:"absolute", top:40, left:"12.5%", right:"12.5%", height:2, background:`linear-gradient(90deg,${RED},${RED_DARK})`, zIndex:0, opacity:0.3 }}/>

          {[
            ["01","📝","Register","Create your donor profile with basic health details and blood group in 5 minutes."],
            ["02","📅","Schedule","Pick a convenient time slot at any of our 200+ partner donation centers."],
            ["03","🩸","Donate","The actual blood draw takes only 8–10 minutes. Relax with refreshments after."],
            ["04","❤️","Save Lives","Your donation is tested, processed, and dispatched to patients within 24 hours."]
          ].map(([num,icon,title,desc],i) => (
            <Card key={num} style={{ textAlign:"center", position:"relative", zIndex:1, padding:"32px 24px" }}>
              <div style={{ position:"absolute", top:-14, left:"50%", transform:"translateX(-50%)", background:`linear-gradient(135deg,${RED},${RED_DARK})`, color:WHITE, fontWeight:800, fontSize:"0.7rem", padding:"3px 10px", borderRadius:20, letterSpacing:"0.08em" }}>{num}</div>
              <div style={{ fontSize:"2.5rem", marginBottom:12, marginTop:8 }}>{icon}</div>
              <div style={{ fontWeight:800, color:SLATE, fontSize:"1.05rem", marginBottom:8 }}>{title}</div>
              <div style={{ color:SLATE_LT, fontSize:"0.85rem", lineHeight:1.65 }}>{desc}</div>
            </Card>
          ))}
        </div>
      </Section>

      {/* ════════════════════════════════════════════════
          PARTNER HOSPITALS
      ════════════════════════════════════════════════ */}
      <Section bg={WHITE} id="hospitals">
        <div style={{ textAlign:"center", marginBottom:48 }}>
          <SectionLabel text="Trusted Network" />
          <SectionTitle>Partner Hospitals</SectionTitle>
          <p style={{ color:SLATE_LT, maxWidth:460, margin:"0 auto", fontSize:"0.95rem" }}>Partnered with India's top healthcare institutions for seamless blood supply chain management.</p>
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:20, marginBottom:40 }} className="three-col">
          {[
            ["🏥","Apollo Hospitals","Mumbai, Delhi, Bangalore","NABH Accredited","400+ Beds"],
            ["🏥","Fortis Healthcare","Pan India (36 facilities)","JCI Certified","500+ Beds"],
            ["🏥","AIIMS","New Delhi","Govt. Premier Institute","2,500+ Beds"],
            ["🏥","Narayana Health","Bengaluru, Kolkata","ISO 9001:2015","350+ Beds"],
            ["🏥","Max Healthcare","Delhi NCR","NABH Accredited","480+ Beds"],
            ["🏥","Kokilaben Hospital","Mumbai","JCI Certified","750+ Beds"]
          ].map(([icon,name,loc,cert,beds]) => (
            <Card key={name} style={{ display:"flex", gap:16, alignItems:"flex-start", padding:"24px 20px" }}>
              <div style={{ fontSize:"2rem", flexShrink:0 }}>{icon}</div>
              <div>
                <div style={{ fontWeight:800, color:SLATE, fontSize:"0.95rem", marginBottom:3 }}>{name}</div>
                <div style={{ color:SLATE_LT, fontSize:"0.8rem", marginBottom:6 }}>{loc}</div>
                <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                  <span style={{ background:`${RED}12`, color:RED, fontSize:"0.72rem", fontWeight:700, padding:"2px 8px", borderRadius:12 }}>{cert}</span>
                  <span style={{ background:`${SLATE}0A`, color:SLATE_MD, fontSize:"0.72rem", fontWeight:600, padding:"2px 8px", borderRadius:12 }}>{beds}</span>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Trust badges */}
        <div style={{ display:"flex", justifyContent:"center", gap:32, flexWrap:"wrap" }}>
          {["✅ NABH Certified","🔒 HIPAA Compliant","🏅 ISO 27001","⭐ 4.9/5 Rating","🔬 WHO Guidelines"].map(b => (
            <div key={b} style={{ color:SLATE_MD, fontWeight:600, fontSize:"0.85rem" }}>{b}</div>
          ))}
        </div>
      </Section>

      {/* ════════════════════════════════════════════════
          TESTIMONIALS
      ════════════════════════════════════════════════ */}
      <Section bg={SMOKE}>
        <div style={{ textAlign:"center", marginBottom:56 }}>
          <SectionLabel text="Real Stories" />
          <SectionTitle>Lives Changed by Donors</SectionTitle>
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:24 }} className="three-col">
          {[
            ["Priya Sharma","Blood Recipient","My daughter needed emergency surgery. HemoCare connected us with a donor in under 20 minutes. I cannot put into words what that means to our family.","⭐⭐⭐⭐⭐","Mumbai","PS"],
            ["Dr. Arjun Mehta","Cardiologist, Apollo","As a physician, I've seen firsthand how HemoCare's real-time inventory system has transformed emergency care. Blood is available when we need it, every time.","⭐⭐⭐⭐⭐","Delhi","AM"],
            ["Sunita Patil","Regular Donor (12× donated)","I've been donating through HemoCare for 3 years. The scheduling is effortless and I love knowing exactly when my donation has been used to help a patient.","⭐⭐⭐⭐⭐","Pune","SP"]
          ].map(([name,role,quote,stars,city,init]) => (
            <Card key={name} style={{ padding:28 }}>
              <div style={{ color:RED, fontSize:"1.5rem", marginBottom:12 }}>❝</div>
              <p style={{ color:SLATE_MD, fontSize:"0.9rem", lineHeight:1.75, marginBottom:20, fontStyle:"italic" }}>"{quote}"</p>
              <div style={{ fontSize:"0.8rem", marginBottom:16 }}>{stars}</div>
              <div style={{ display:"flex", alignItems:"center", gap:12, borderTop:`1px solid ${BORDER}`, paddingTop:16 }}>
                <div style={{ width:40, height:40, borderRadius:"50%", background:`linear-gradient(135deg,${RED},${RED_DARK})`, color:WHITE, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:800, fontSize:"0.85rem", flexShrink:0 }}>{init}</div>
                <div>
                  <div style={{ fontWeight:700, color:SLATE, fontSize:"0.9rem" }}>{name}</div>
                  <div style={{ color:SLATE_LT, fontSize:"0.78rem" }}>{role} · {city}</div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </Section>

      {/* ════════════════════════════════════════════════
          CAMPAIGNS
      ════════════════════════════════════════════════ */}
      <Section bg={WHITE}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginBottom:40, flexWrap:"wrap", gap:16 }}>
          <div>
            <SectionLabel text="Upcoming Events" />
            <SectionTitle>Blood Donation Campaigns</SectionTitle>
          </div>
          <GhostBtn>View All Events →</GhostBtn>
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:24 }} className="three-col">
          {[
            ["🌅","July 15, 2026","World Blood Donor Day Drive","AIIMS, New Delhi","Target: 500 units","Open Registration"],
            ["🏢","July 22, 2026","Corporate Blood Camp","Infosys Campus, Bengaluru","Target: 200 units","Limited Spots"],
            ["🏫","Aug 3, 2026","College Donation Drive","IIT Bombay","Target: 300 units","Open Registration"]
          ].map(([icon,date,title,loc,target,status]) => {
            const limited = status==="Limited Spots";
            return (
              <Card key={title} style={{ padding:0, overflow:"hidden" }}>
                <div style={{ background:`linear-gradient(135deg,${limited?RED_DARK:"#1E40AF"},${limited?RED:"#3B82F6"})`, padding:"20px 24px" }}>
                  <div style={{ fontSize:"2rem", marginBottom:4 }}>{icon}</div>
                  <div style={{ color:"rgba(255,255,255,0.75)", fontSize:"0.8rem", fontWeight:600 }}>{date}</div>
                </div>
                <div style={{ padding:"20px 24px" }}>
                  <div style={{ fontWeight:800, color:SLATE, marginBottom:6 }}>{title}</div>
                  <div style={{ color:SLATE_LT, fontSize:"0.85rem", marginBottom:12 }}>📍 {loc}</div>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ color:SLATE_MD, fontSize:"0.82rem", fontWeight:600 }}>🎯 {target}</span>
                    <span style={{ background:limited?`${RED}12`:"#DCFCE7", color:limited?RED:"#16A34A", fontSize:"0.75rem", fontWeight:700, padding:"3px 10px", borderRadius:16 }}>{status}</span>
                  </div>
                  <PrimaryBtn style={{ width:"100%", marginTop:16, padding:"11px", borderRadius:10, display:"block" }}>Register Free</PrimaryBtn>
                </div>
              </Card>
            );
          })}
        </div>
      </Section>

      {/* ════════════════════════════════════════════════
          CTA BANNER
      ════════════════════════════════════════════════ */}
      <section style={{ background:`linear-gradient(135deg,${SLATE},#0F172A)`, padding:"80px 24px", textAlign:"center" }}>
        <div style={{ maxWidth:640, margin:"0 auto" }}>
          <div style={{ fontSize:"3rem", marginBottom:16 }}>🩸</div>
          <h2 style={{ fontFamily:FONT, fontWeight:900, fontSize:"clamp(2rem,5vw,3rem)", color:WHITE, lineHeight:1.1, marginBottom:16 }}>
            Every Drop Counts
          </h2>
          <p style={{ color:"rgba(255,255,255,0.6)", fontSize:"1rem", lineHeight:1.7, marginBottom:36 }}>
            It costs you nothing but an hour. It could mean everything to someone in need. Join 48,000+ donors today.
          </p>
          <div style={{ display:"flex", gap:12, justifyContent:"center", flexWrap:"wrap" }}>
            <PrimaryBtn style={{ padding:"16px 40px", fontSize:"1rem", borderRadius:14 }}>🩸 Start Donating</PrimaryBtn>
            <GhostBtn dark style={{ padding:"16px 40px", fontSize:"1rem", borderRadius:14 }}>Learn More</GhostBtn>
          </div>
        </div>
      </section>

      {/* ════════════════════════════════════════════════
          FOOTER
      ════════════════════════════════════════════════ */}
      <footer style={{ background:"#0F172A", color:"rgba(255,255,255,0.55)", padding:"64px 24px 32px" }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr 1fr 1fr", gap:40, marginBottom:48 }} className="four-col">

            {/* Brand */}
            <div>
              <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:16 }}>
                <div style={{ width:36, height:36, borderRadius:10, background:`linear-gradient(135deg,${RED},${RED_DARK})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.2rem" }}>🩸</div>
                <span style={{ fontWeight:900, fontSize:"1.2rem", color:WHITE }}>Hemo<span style={{ color:RED }}>Care</span></span>
              </div>
              <p style={{ fontSize:"0.88rem", lineHeight:1.7, maxWidth:280, marginBottom:20 }}>
                India's most trusted Blood Bank Management System — connecting donors, hospitals, and patients since 2019.
              </p>
              <div style={{ display:"flex", gap:12 }}>
                {["𝕏","in","f","📧"].map(s => (
                  <div key={s} style={{ width:36, height:36, borderRadius:8, background:"rgba(255,255,255,0.08)", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", fontSize:"0.85rem", transition:"background 0.2s" }}
                    onMouseEnter={e => e.currentTarget.style.background = RED}
                    onMouseLeave={e => e.currentTarget.style.background = "rgba(255,255,255,0.08)"}
                  >{s}</div>
                ))}
              </div>
            </div>

            {/* Links */}
            {[
              ["Quick Links",["Home","Find Blood","Donate Now","Campaigns","About Us","Careers"]],
              ["Services",["Blood Search","Emergency Request","Donor Registration","Hospital Portal","Reports","API Access"]],
              ["Support",["Help Center","Contact Us","Privacy Policy","Terms of Service","Cookie Policy","Accessibility"]]
            ].map(([title,links]) => (
              <div key={title}>
                <div style={{ fontWeight:700, color:WHITE, fontSize:"0.9rem", marginBottom:16 }}>{title}</div>
                {links.map(l => (
                  <button key={l} style={{ display:"block", color:"rgba(255,255,255,0.5)", fontSize:"0.85rem", marginBottom:9, textDecoration:"none", transition:"color 0.2s", background:"none", border:"none", cursor:"pointer", textAlign:"left", padding:0 }}
                    onMouseEnter={e => e.target.style.color = WHITE}
                    onMouseLeave={e => e.target.style.color = "rgba(255,255,255,0.5)"}
                  >{l}</button>
                ))}
              </div>
            ))}
          </div>

          {/* Emergency bar */}
          <div style={{ background:`${RED}20`, border:`1px solid ${RED}40`, borderRadius:12, padding:"16px 24px", marginBottom:32, display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:12 }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <span style={{ fontSize:"1.3rem" }}>🚨</span>
              <span style={{ color:WHITE, fontWeight:700 }}>24/7 Emergency Helpline</span>
            </div>
            <a href="tel:+911800-BLOOD-1" style={{ color:"#FCA5A5", fontWeight:800, fontSize:"1.05rem", textDecoration:"none" }}>+91 1800-BLOOD-1 (25663-1)</a>
          </div>

          {/* Bottom bar */}
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", paddingTop:24, borderTop:"1px solid rgba(255,255,255,0.08)", flexWrap:"wrap", gap:12 }}>
            <span style={{ fontSize:"0.82rem" }}>© 2026 HemoCare. All rights reserved.</span>
            <span style={{ fontSize:"0.82rem" }}>Made with ❤️ for patients, by donors.</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
