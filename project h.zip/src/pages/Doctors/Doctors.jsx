import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaUserDoctor,
  FaPlus,
  FaMagnifyingGlass,
  FaStethoscope,
  FaEnvelope,
  FaPhone,
  FaCalendar,
  FaStar,
  FaClock,
  FaPencil,
  FaEye,
  FaTrash
} from 'react-icons/fa6';
import DashboardLayout from '../../components/DashboardLayout';

/* Design Tokens matching Dashboard */
const FONT = "'Inter','Segoe UI',system-ui,sans-serif";
const RED = "#C41230";
const RED_DARK = "#8B0000";
const RED_GLOW = "rgba(196,18,48,0.15)";
const SLATE = "#1E293B";
const SLATE_MD = "#334155";
const SLATE_LT = "#64748B";
const SMOKE = "#F8FAFC";
const WHITE = "#FFFFFF";
const BORDER = "#E2E8F0";

function Doctors() {
  const navigate = useNavigate();
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSpecialty, setFilterSpecialty] = useState('all');

  useEffect(() => {
    fetchDoctors();
  }, []);

  const fetchDoctors = async () => {
    try {
      const storedDoctors = localStorage.getItem('doctors');
      if (storedDoctors) {
        setDoctors(JSON.parse(storedDoctors));
        setLoading(false);
      } else {
        const mockDoctors = [
          {
            id: 1,
            name: 'Dr. Sarah Johnson',
            specialty: 'Cardiology',
            email: 'sarah.johnson@hospital.com',
            phone: '555-0201',
            qualification: 'MD, FACC',
            experience: 15,
            rating: 4.8,
            availability: 'Available',
            department: 'Cardiology'
          },
          {
            id: 2,
            name: 'Dr. Michael Chen',
            specialty: 'Neurology',
            email: 'm.chen@hospital.com',
            phone: '555-0202',
            qualification: 'MD, PhD',
            experience: 12,
            rating: 4.9,
            availability: 'In Surgery',
            department: 'Neurology'
          },
          {
            id: 3,
            name: 'Dr. Emily Williams',
            specialty: 'Pediatrics',
            email: 'e.williams@hospital.com',
            phone: '555-0203',
            qualification: 'MD, FAAP',
            experience: 8,
            rating: 4.7,
            availability: 'Available',
            department: 'Pediatrics'
          }
        ];
        localStorage.setItem('doctors', JSON.stringify(mockDoctors));
        setDoctors(mockDoctors);
        setLoading(false);
      }
    } catch (error) {
      console.error('Error fetching doctors:', error);
      setLoading(false);
    }
  };

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterSpecialty === 'all' || doctor.specialty === filterSpecialty;
    return matchesSearch && matchesFilter;
  });

  const getAvailabilityColor = (availability) => {
    switch (availability) {
      case 'Available': return '#16A34A';
      case 'In Surgery': return '#D97706';
      case 'On Leave': return RED;
      default: return SLATE_LT;
    }
  };

  const getRatingStars = (rating) => {
    const stars = [];
    const val = rating || 5.0;
    for (let i = 1; i <= 5; i++) {
      if (i <= Math.floor(val)) {
        stars.push(<FaStar key={i} className="star-filled" style={{ color: '#FBBF24', marginRight: '2px' }} />);
      } else if (i - 0.5 <= val) {
        stars.push(<FaStar key={i} className="star-half" style={{ color: '#FBBF24', marginRight: '2px' }} />);
      } else {
        stars.push(<FaStar key={i} className="star-empty" style={{ color: '#CBD5E1', marginRight: '2px' }} />);
      }
    }
    return stars;
  };

  return (
    <DashboardLayout activeTab="doctors" title="Doctors Console" subtitle="Manage medical staff schedules, rosters, and dossiers">
      <div style={{ fontFamily:FONT }}>
        {/* Page Header */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:28 }}>
          <h2 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.5rem', color:SLATE, lineHeight:1.2 }}>Medical Staff Roster</h2>
          <button 
            onClick={() => navigate('/doctors/add')}
            style={{ 
              background:`linear-gradient(135deg,${RED},${RED_DARK})`,
              color:WHITE, border:'none', borderRadius:12, padding:'12px 24px',
              fontFamily:FONT, fontSize:'0.9rem', fontWeight:700, cursor:'pointer',
              display:'flex', alignItems:'center', gap:8,
              boxShadow:`0 4px 16px ${RED_GLOW}`,
              transition:'all 0.25s'
            }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = `0 8px 24px ${RED_GLOW}`; }}
            onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = `0 4px 16px ${RED_GLOW}`; }}
          >
            <FaPlus /> Add Doctor
          </button>
        </div>

        {/* Filters */}
        <div style={{ display:'flex', gap:16, marginBottom:28 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10, background:SMOKE, border:`1px solid ${BORDER}`, borderRadius:14, padding:'10px 16px', flex:1, maxWidth:400 }}>
            <FaMagnifyingGlass style={{ color:SLATE_LT, fontSize:'0.95rem' }} />
            <input
              type="text"
              placeholder="Search doctors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ border:'none', background:'transparent', fontFamily:FONT, fontSize:'0.9rem', color:SLATE, outline:'none', width:'100%' }}
            />
          </div>

          <div style={{ position:'relative' }}>
            <select
              value={filterSpecialty}
              onChange={(e) => setFilterSpecialty(e.target.value)}
              style={{
                padding:'10px 16px', borderRadius:14, border:`1px solid ${BORDER}`,
                fontFamily:FONT, fontSize:'0.9rem', color:SLATE, outline:'none',
                background:SMOKE, cursor:'pointer', appearance:'none', paddingRight:40
              }}
            >
              <option value="all">All Specialties</option>
              <option value="Cardiology">Cardiology</option>
              <option value="Neurology">Neurology</option>
              <option value="Pediatrics">Pediatrics</option>
              <option value="Orthopedics">Orthopedics</option>
              <option value="General Medicine">General Medicine</option>
            </select>
          </div>
        </div>

        {loading ? (
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', minHeight:300, gap:12 }}>
            <div style={{ width:48, height:48, borderRadius:'50%', border:`3px solid ${BORDER}`, borderTopColor:RED, animation:'spin 0.9s linear infinite' }} />
            <style>{"@keyframes spin{to{transform:rotate(360deg)}}"}</style>
            <p style={{ color:SLATE_LT, fontWeight:600 }}>Loading medical directory...</p>
          </div>
        ) : (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(340px,1fr))', gap:20 }}>
            {filteredDoctors.length > 0 ? (
              filteredDoctors.map(doctor => (
                <div key={doctor.id} style={{
                  background:WHITE, borderRadius:20, border:`1px solid ${BORDER}`,
                  padding:24, boxShadow:'0 4px 20px rgba(0,0,0,0.06)',
                  transition:'all 0.3s', cursor:'pointer'
                }}
                  onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 20px 60px rgba(0,0,0,0.12)'; }}
                  onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.06)'; }}
                >
                  {/* Header */}
                  <div style={{ display:'flex', alignItems:'flex-start', gap:14, marginBottom:16 }}>
                    <div style={{ 
                      width:56, height:56, borderRadius:16, 
                      background:`linear-gradient(135deg,${RED},${RED_DARK})`,
                      display:'flex', alignItems:'center', justifyContent:'center',
                      color:WHITE, fontWeight:800, fontSize:'1.4rem', flexShrink:0
                    }}>
                      {doctor.name.split(' ').slice(-1)[0]?.charAt(0) || 'D'}
                    </div>
                    <div style={{ flex:1 }}>
                      <h3 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.1rem', color:SLATE, lineHeight:1.2, marginBottom:4 }}>{doctor.name}</h3>
                      <div style={{ color:SLATE_LT, fontSize:'0.85rem', fontWeight:500, marginBottom:6 }}>{doctor.specialty}</div>
                      <div style={{ display:'flex', alignItems:'center', gap:4 }}>
                        {getRatingStars(doctor.rating)}
                        <span style={{ color:SLATE_LT, fontSize:'0.8rem' }}>({doctor.rating || '5.0'})</span>
                      </div>
                    </div>
                    <div style={{ 
                      padding:'4px 10px', borderRadius:12, fontSize:'0.75rem', fontWeight:700,
                      background:`${getAvailabilityColor(doctor.availability)}15`,
                      color:getAvailabilityColor(doctor.availability)
                    }}>
                      {doctor.availability}
                    </div>
                  </div>

                  {/* Details */}
                  <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:16, padding:'16px', background:SMOKE, borderRadius:14 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'0.85rem', color:SLATE_MD }}>
                      <FaStethoscope style={{ color:RED, fontSize:'0.9rem' }} />
                      <span><strong>{doctor.qualification}</strong></span>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'0.85rem', color:SLATE_MD }}>
                      <FaClock style={{ color:SLATE_LT, fontSize:'0.9rem' }} />
                      <span>{doctor.experience} years experience</span>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'0.85rem', color:SLATE_MD }}>
                      <FaEnvelope style={{ color:SLATE_LT, fontSize:'0.9rem' }} />
                      <span>{doctor.email}</span>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'0.85rem', color:SLATE_MD }}>
                      <FaPhone style={{ color:SLATE_LT, fontSize:'0.9rem' }} />
                      <span>{doctor.phone}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div style={{ display:'flex', gap:8 }}>
                    <button 
                      onClick={() => navigate(`/doctors/${doctor.id}`)}
                      style={{ 
                        flex:1, padding:'10px 16px', borderRadius:10, border:`1px solid ${BORDER}`,
                        background:WHITE, color:SLATE, fontFamily:FONT, fontSize:'0.85rem',
                        fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center',
                        justifyContent:'center', gap:6, transition:'all 0.2s'
                      }}
                      onMouseEnter={e => { e.currentTarget.style.background = SMOKE; e.currentTarget.style.borderColor = RED; }}
                      onMouseLeave={e => { e.currentTarget.style.background = WHITE; e.currentTarget.style.borderColor = BORDER; }}
                    >
                      <FaEye /> View
                    </button>
                    <button 
                      onClick={() => navigate(`/doctors/${doctor.id}/edit`)}
                      style={{ 
                        flex:1, padding:'10px 16px', borderRadius:10, border:`1px solid ${BORDER}`,
                        background:WHITE, color:SLATE, fontFamily:FONT, fontSize:'0.85rem',
                        fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center',
                        justifyContent:'center', gap:6, transition:'all 0.2s'
                      }}
                      onMouseEnter={e => { e.currentTarget.style.background = SMOKE; e.currentTarget.style.borderColor = RED; }}
                      onMouseLeave={e => { e.currentTarget.style.background = WHITE; e.currentTarget.style.borderColor = BORDER; }}
                    >
                      <FaPencil /> Edit
                    </button>
                    <button 
                      onClick={() => {
                        const updated = doctors.filter(d => d.id !== doctor.id);
                        setDoctors(updated);
                        localStorage.setItem('doctors', JSON.stringify(updated));
                      }}
                      style={{ 
                        padding:'10px 16px', borderRadius:10, border:`1px solid ${RED}`,
                        background:`${RED}10`, color:RED, fontFamily:FONT, fontSize:'0.85rem',
                        fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center',
                        justifyContent:'center', gap:6, transition:'all 0.2s'
                      }}
                      onMouseEnter={e => { e.currentTarget.style.background = RED; e.currentTarget.style.color = WHITE; }}
                      onMouseLeave={e => { e.currentTarget.style.background = `${RED}10`; e.currentTarget.style.color = RED; }}
                    >
                      <FaTrash />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div style={{ gridColumn:'1/-1', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', minHeight:300, gap:16 }}>
                <FaUserDoctor style={{ fontSize:'4rem', color:SLATE_LT }} />
                <h3 style={{ fontFamily:FONT, fontWeight:700, fontSize:'1.2rem', color:SLATE }}>No doctors found</h3>
                <p style={{ color:SLATE_LT, fontSize:'0.9rem' }}>Try adjusting your search or filter criteria</p>
              </div>
            )}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

export default Doctors;