import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaArrowLeft, FaUserDoctor, FaStethoscope, FaGraduationCap } from 'react-icons/fa6';
import './Doctors.css';

function AddDoctor() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '',
    specialty: '',
    qualification: '',
    experience: '',
    email: '',
    phone: '',
    address: '',
    department: '',
    licenseNumber: '',
    availability: 'Available',
    consultationFee: '',
    biography: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Basic validation
      if (!formData.firstName || !formData.lastName || !formData.specialty || !formData.email) {
        setError('Please fill in all required fields');
        setLoading(false);
        return;
      }

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      navigate('/doctors');
    } catch (err) {
      setError('Failed to add doctor. Please try again.');
      setLoading(false);
    }
  };

  const specialties = ['Cardiology', 'Neurology', 'Pediatrics', 'Orthopedics', 'General Medicine', 'Dermatology', 'Ophthalmology'];
  const genders = ['Male', 'Female', 'Other'];

  return (
    <div className="add-doctor-page">
      <div className="page-header">
        <button className="btn-outline" onClick={() => navigate('/doctors')}>
          <FaArrowLeft /> Back to Doctors
        </button>
        <h1>Add New Doctor</h1>
        <div></div>
      </div>

      {error && <div className="error-alert">{error}</div>}

      <form onSubmit={handleSubmit} className="doctor-form">
        <div className="form-section">
          <h2><FaUserDoctor /> Personal Information</h2>
          <div className="form-grid">
            <div className="form-group">
              <label>First Name *</label>
              <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Last Name *</label>
              <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Date of Birth</label>
              <input type="date" name="dateOfBirth" value={formData.dateOfBirth} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>Gender</label>
              <select name="gender" value={formData.gender} onChange={handleChange}>
                <option value="">Select Gender</option>
                {genders.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Email *</label>
              <input type="email" name="email" value={formData.email} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Phone *</label>
              <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Address</label>
              <input type="text" name="address" value={formData.address} onChange={handleChange} />
            </div>
          </div>
        </div>

        <div className="form-section">
          <h2><FaStethoscope /> Professional Information</h2>
          <div className="form-grid">
            <div className="form-group">
              <label>Specialty *</label>
              <select name="specialty" value={formData.specialty} onChange={handleChange} required>
                <option value="">Select Specialty</option>
                {specialties.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Qualification *</label>
              <input type="text" name="qualification" value={formData.qualification} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Years of Experience *</label>
              <input type="number" name="experience" value={formData.experience} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Department *</label>
              <input type="text" name="department" value={formData.department} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>License Number</label>
              <input type="text" name="licenseNumber" value={formData.licenseNumber} onChange={handleChange} />
            </div>
            <div className="form-group">
              <label>Consultation Fee</label>
              <input type="number" name="consultationFee" value={formData.consultationFee} onChange={handleChange} />
            </div>
          </div>
        </div>

        <div className="form-section">
          <h2><FaGraduationCap /> Additional Information</h2>
          <div className="form-group">
            <label>Biography</label>
            <textarea name="biography" value={formData.biography} onChange={handleChange} rows="4" />
          </div>
        </div>

        <div className="form-actions">
          <button type="button" className="btn-outline" onClick={() => navigate('/doctors')} disabled={loading}>
            Cancel
          </button>
          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? 'Adding Doctor...' : 'Add Doctor'}
          </button>
        </div>
      </form>
    </div>
  );
}

export default AddDoctor;