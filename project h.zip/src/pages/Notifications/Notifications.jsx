import React, { useState } from 'react';
import { FaBell, FaCheckDouble, FaTrash } from 'react-icons/fa6';
import './Notifications.css';

function Notifications() {
  const [filter, setFilter] = useState('all');
  const [notifications, setNotifications] = useState([
    { id: 1, title: 'Blood Stock Alert', message: 'O+ blood type is running low (12 units remaining)', time: '2 minutes ago', read: false, type: 'critical' },
    { id: 2, title: 'New Appointment', message: 'Dr. Johnson has a new appointment scheduled', time: '15 minutes ago', read: false, type: 'info' },
    { id: 3, title: 'Donation Received', message: '5 units of A+ blood received from Central Blood Bank', time: '1 hour ago', read: true, type: 'success' },
    { id: 4, title: 'System Update', message: 'Scheduled maintenance in 2 hours', time: '3 hours ago', read: true, type: 'warning' }
  ]);

  const markAsRead = (id) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const deleteNotification = (id) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const filteredNotifications = filter === 'all' ? notifications : notifications.filter(n => !n.read);

  const getTypeColor = (type) => {
    switch (type) {
      case 'critical': return '#EF4444';
      case 'success': return '#10B981';
      case 'warning': return '#F59E0B';
      default: return '#3B82F6';
    }
  };

  return (
    <div className="notifications-page">
      <div className="page-header">
        <div className="page-title-section">
          <div className="page-icon"><FaBell /></div>
          <div>
            <h1>Notifications</h1>
            <p>{notifications.filter(n => !n.read).length} unread notifications</p>
          </div>
        </div>
        <div className="header-actions">
          <button className="btn-outline" onClick={markAllAsRead}>
            <FaCheckDouble /> Mark All Read
          </button>
        </div>
      </div>

      <div className="page-filters">
        <div className="filter-tabs">
          <button className={`filter-tab ${filter === 'all' ? 'active' : ''}`} onClick={() => setFilter('all')}>
            All
          </button>
          <button className={`filter-tab ${filter === 'unread' ? 'active' : ''}`} onClick={() => setFilter('unread')}>
            Unread
          </button>
        </div>
      </div>

      <div className="notifications-list">
        {filteredNotifications.length > 0 ? (
          filteredNotifications.map(notification => (
            <div key={notification.id} className={`notification-item ${!notification.read ? 'unread' : ''}`}>
              <div className="notification-indicator" style={{ backgroundColor: getTypeColor(notification.type) }} />
              <div className="notification-content">
                <div className="notification-header">
                  <h3>{notification.title}</h3>
                  <span className="notification-time">{notification.time}</span>
                </div>
                <p>{notification.message}</p>
              </div>
              <div className="notification-actions">
                {!notification.read && (
                  <button className="action-btn" onClick={() => markAsRead(notification.id)} title="Mark as read">
                    <FaCheckDouble />
                  </button>
                )}
                <button className="action-btn" onClick={() => deleteNotification(notification.id)} title="Delete">
                  <FaTrash />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="empty-state">
            <FaBell className="empty-icon" />
            <h3>No notifications</h3>
            <p>You're all caught up!</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Notifications;