import React, { useState, useEffect, useRef } from "react";
import {
  FaUsers, FaUserDoctor, FaDroplet, FaHeartPulse, FaBell,
  FaClipboardList, FaRightFromBracket, FaChartLine,
  FaGear, FaCalendarDays, FaHandHoldingMedical,
  FaSun, FaMoon, FaHospital,
  FaArrowTrendUp, FaArrowTrendDown, FaMagnifyingGlass, FaBars,
} from "react-icons/fa6";
import { useAuth, useUser } from "@clerk/clerk-react";
import { useNavigate } from "react-router-dom";

/* ─────────────────────────────────────────────────
   DESIGN TOKENS
───────────────────────────────────────────────── */
const FONT    = "'Inter','Segoe UI',system-ui,sans-serif";
const RED     = "#C41230";
const RED_DK  = "#8B0000";
const RED_GL  = "rgba(196,18,48,0.12)";
const NAVY    = "#0F172A";
const NAVY2   = "#1E293B";
const SLATE   = "#334155";
const SLATE_L = "#64748B";
const BORDER  = "#E2E8F0";
const SMOKE   = "#F8FAFC";
const WHITE   = "#FFFFFF";

const SIDEBAR_W   = 260;
const SIDEBAR_COL = NAVY;

const BG_COLOR = {
  "A+":"#16A34A","A-":"#15803D","B+":"#2563EB","B-":"#1D4ED8",
  "AB+":"#7C3AED","AB-":"#6D28D9","O+":RED,"O-":RED_DK
};

/* ─────────────────────────────────────────────────
   TINY HELPERS
───────────────────────────────────────────────── */
function BloodBadge({ group, size = "sm" }) {
  const pad = size === "lg" ? "6px 14px" : "3px 9px";
  const fs  = size === "lg" ? "0.85rem" : "0.72rem";
  return (
    <span style={{ background:BG_COLOR[group]||RED, color:WHITE, fontWeight:800, fontSize:fs, padding:pad, borderRadius:20, whiteSpace:"nowrap" }}>
      {group}
    </span>
  );
}

function StatusPill({ status }) {
  const map = {
    "Available"   : ["#16A34A","#DCFCE7"],
    "Low Stock"   : ["#D97706","#FEF3C7"],
    "Critical"    : [RED,"#FEE2E2"],
    "Pending"     : ["#D97706","#FEF3C7"],
    "Approved"    : ["#16A34A","#DCFCE7"],
    "Dispatched"  : ["#2563EB","#DBEAFE"],
    "Completed"   : ["#64748B","#F1F5F9"],
  };
  const [fg, bg] = map[status] || ["#64748B","#F1F5F9"];
  return (
    <span style={{ color:fg, background:bg, fontWeight:700, fontSize:"0.74rem", padding:"4px 10px", borderRadius:20, whiteSpace:"nowrap" }}>
      {status}
    </span>
  );
}

function AnimatedCounter({ target }) {
  const [val, setVal] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        let n = 0;
        const step = Math.max(1, Math.ceil(target / 50));
        const t = setInterval(() => { n += step; if (n >= target) { setVal(target); clearInterval(t); } else setVal(n); }, 25);
        obs.disconnect();
      }
    }, { threshold: 0.4 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [target]);
  return <span ref={ref}>{val.toLocaleString()}</span>;
}

/* ─────────────────────────────────────────────────
   SIDEBAR
───────────────────────────────────────────────── */
function Sidebar({ active, navigate, onLogout, collapsed }) {
  const nav = [
    { key:"dashboard",       icon:<FaChartLine/>,        label:"Dashboard"       },
    { key:"patients",        icon:<FaUsers/>,            label:"Patients"        },
    { key:"doctors",         icon:<FaUserDoctor/>,       label:"Doctors"         },
    { key:"donors",          icon:<FaHandHoldingMedical/>,label:"Donors"         },
    { key:"blood-inventory", icon:<FaDroplet/>,          label:"Blood Inventory" },
    { key:"blood-requests",  icon:<FaHeartPulse/>,       label:"Blood Requests"  },
    { key:"appointments",    icon:<FaCalendarDays/>,     label:"Appointments"    },
    { key:"hospitals",       icon:<FaHospital/>,         label:"Hospitals"       },
    { key:"reports",         icon:<FaClipboardList/>,    label:"Reports"         },
    { key:"settings",        icon:<FaGear/>,             label:"Settings"        },
  ];

  const w = collapsed ? 68 : SIDEBAR_W;

  return (
    <aside style={{
      width:w, minHeight:"100vh", background:SIDEBAR_COL,
      position:"fixed", top:0, left:0, zIndex:200,
      display:"flex", flexDirection:"column",
      transition:"width 0.3s cubic-bezier(.4,0,.2,1)",
      overflow:"hidden", boxShadow:"4px 0 30px rgba(0,0,0,0.2)"
    }}>
      {/* Logo */}
      <div style={{ padding: collapsed ? "24px 0" : "24px 20px", display:"flex", alignItems:"center", gap:10, height:72, borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ width:36, height:36, borderRadius:10, background:`linear-gradient(135deg,${RED},${RED_DK})`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.1rem", flexShrink:0, margin: collapsed ? "0 auto" : 0 }}>🩸</div>
        {!collapsed && <span style={{ fontWeight:900, color:WHITE, fontSize:"1.15rem", whiteSpace:"nowrap" }}>Hemo<span style={{ color:RED }}>Care</span></span>}
      </div>

      {/* Section label */}
      {!collapsed && <div style={{ padding:"20px 20px 8px", color:"rgba(255,255,255,0.3)", fontSize:"0.68rem", fontWeight:700, letterSpacing:"0.1em" }}>NAVIGATION</div>}

      {/* Nav items */}
      <nav style={{ flex:1, padding: collapsed ? "8px 6px" : "8px 12px", overflowY:"auto" }}>
        {nav.map(({ key, icon, label }) => {
          const isActive = active === key;
          return (
            <div key={key} onClick={() => navigate(`/${key}`)}
              title={collapsed ? label : ""}
              style={{
                display:"flex", alignItems:"center", gap:12, padding: collapsed ? "12px 0" : "11px 14px",
                borderRadius:10, margin:"2px 0", cursor:"pointer",
                background: isActive ? `linear-gradient(135deg,${RED}CC,${RED_DK})` : "transparent",
                color: isActive ? WHITE : "rgba(255,255,255,0.55)",
                fontWeight: isActive ? 700 : 500, fontSize:"0.88rem",
                transition:"all 0.2s", justifyContent: collapsed ? "center" : "flex-start",
                boxShadow: isActive ? `0 4px 16px ${RED}40` : "none"
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "rgba(255,255,255,0.05)"; e.currentTarget.style.color = WHITE; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = isActive ? WHITE : "rgba(255,255,255,0.55)"; }}
            >
              <span style={{ fontSize:"1rem", flexShrink:0 }}>{icon}</span>
              {!collapsed && <span>{label}</span>}
            </div>
          );
        })}
      </nav>

      {/* Logout */}
      <div style={{ padding: collapsed ? "16px 6px" : "16px 12px", borderTop:"1px solid rgba(255,255,255,0.06)" }}>
        <div onClick={onLogout}
          style={{ display:"flex", alignItems:"center", gap:12, padding: collapsed ? "12px 0" : "11px 14px", borderRadius:10, cursor:"pointer", color:"rgba(255,100,100,0.7)", fontWeight:600, fontSize:"0.88rem", transition:"all 0.2s", justifyContent: collapsed ? "center" : "flex-start" }}
          onMouseEnter={e => { e.currentTarget.style.background = "rgba(239,68,68,0.1)"; e.currentTarget.style.color = "#FCA5A5"; }}
          onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "rgba(255,100,100,0.7)"; }}
        >
          <FaRightFromBracket style={{ flexShrink:0 }}/>{!collapsed && <span>Sign Out</span>}
        </div>
      </div>
    </aside>
  );
}

/* ─────────────────────────────────────────────────
   TOPBAR
───────────────────────────────────────────────── */
function Topbar({ displayName, displayRole, user, profile, theme, toggleTheme, sidebarCollapsed, toggleSidebar }) {
  const navigate = useNavigate();
  const [dropdown, setDropdown] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const initials = user?.firstName ? `${user.firstName[0]}${user.lastName?.[0]||""}` : "U";

  const notifications = [
    { icon:"🚨", text:"Emergency O- request — 2 units needed", time:"2m ago", urgent:true },
    { icon:"✅", text:"Donor intake completed — A+ blood processed", time:"15m ago", urgent:false },
    { icon:"⚠️", text:"B- stock below threshold (12 units)", time:"1h ago", urgent:false },
    { icon:"📅", text:"3 appointments scheduled for tomorrow", time:"2h ago", urgent:false },
  ];

  return (
    <header style={{
      position:"fixed", top:0, left: sidebarCollapsed ? 68 : SIDEBAR_W, right:0, height:72, zIndex:100,
      background:WHITE, borderBottom:`1px solid ${BORDER}`,
      display:"flex", alignItems:"center", justifyContent:"space-between",
      padding:"0 28px", boxShadow:"0 1px 20px rgba(0,0,0,0.05)",
      transition:"left 0.3s cubic-bezier(.4,0,.2,1)"
    }}>
      {/* Left */}
      <div style={{ display:"flex", alignItems:"center", gap:16 }}>
        <button onClick={toggleSidebar} style={{ width:36, height:36, border:`1px solid ${BORDER}`, borderRadius:8, background:SMOKE, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:SLATE_L }}>
          <FaBars/>
        </button>
        <div>
          <h1 style={{ fontFamily:FONT, fontWeight:800, fontSize:"1.35rem", color:NAVY2, letterSpacing:"-0.01em", lineHeight:1 }}>Operations Console</h1>
          <p style={{ color:SLATE_L, fontSize:"0.8rem", marginTop:2 }}>
            Welcome back, <strong style={{ color:NAVY2 }}>{displayName}</strong>
            <span style={{ background:RED_GL, color:RED, fontWeight:700, fontSize:"0.72rem", padding:"2px 8px", borderRadius:12, marginLeft:8, textTransform:"capitalize" }}>{displayRole.replace("_"," ")}</span>
          </p>
        </div>
      </div>

      {/* Right */}
      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
        {/* Search */}
        <div style={{ display:"flex", alignItems:"center", gap:8, background:SMOKE, border:`1px solid ${BORDER}`, borderRadius:10, padding:"8px 14px" }}>
          <FaMagnifyingGlass style={{ color:SLATE_L, fontSize:"0.85rem" }}/>
          <input placeholder="Search…" style={{ border:"none", background:"transparent", fontFamily:FONT, fontSize:"0.85rem", color:SLATE, outline:"none", width:160 }}/>
        </div>

        {/* Theme */}
        <button onClick={toggleTheme} style={{ width:38, height:38, borderRadius:10, border:`1px solid ${BORDER}`, background:SMOKE, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:SLATE_L, transition:"all 0.2s" }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = RED; e.currentTarget.style.color = RED; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = BORDER; e.currentTarget.style.color = SLATE_L; }}
        >
          {theme === "dark" ? <FaSun/> : <FaMoon/>}
        </button>

        {/* Notifications */}
        <div style={{ position:"relative" }}>
          <button onClick={() => { setNotifOpen(o => !o); setDropdown(false); }}
            style={{ width:38, height:38, borderRadius:10, border:`1px solid ${BORDER}`, background:SMOKE, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:SLATE_L, position:"relative" }}
          >
            <FaBell/>
            <span style={{ position:"absolute", top:6, right:6, width:8, height:8, borderRadius:"50%", background:RED, border:`2px solid ${WHITE}` }}/>
          </button>
          {notifOpen && (
            <div style={{ position:"absolute", right:0, top:48, width:340, background:WHITE, border:`1px solid ${BORDER}`, borderRadius:16, boxShadow:"0 16px 48px rgba(0,0,0,0.12)", zIndex:300, overflow:"hidden" }}>
              <div style={{ padding:"16px 20px", borderBottom:`1px solid ${BORDER}`, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontWeight:800, color:NAVY2 }}>Notifications</span>
                <span style={{ background:RED, color:WHITE, fontSize:"0.7rem", fontWeight:800, padding:"2px 7px", borderRadius:12 }}>4</span>
              </div>
              {notifications.map((n,i) => (
                <div key={i} style={{ padding:"12px 20px", borderBottom:`1px solid ${BORDER}`, display:"flex", gap:12, cursor:"pointer", background:n.urgent?"#FFF5F5":WHITE,
                  transition:"background 0.15s" }}
                  onMouseEnter={e => e.currentTarget.style.background = SMOKE}
                  onMouseLeave={e => e.currentTarget.style.background = n.urgent?"#FFF5F5":WHITE}
                >
                  <span style={{ fontSize:"1.2rem", flexShrink:0 }}>{n.icon}</span>
                  <div>
                    <p style={{ fontSize:"0.83rem", color:NAVY2, fontWeight:n.urgent?700:500, lineHeight:1.5 }}>{n.text}</p>
                    <span style={{ fontSize:"0.75rem", color:SLATE_L }}>{n.time}</span>
                  </div>
                </div>
              ))}
              <div style={{ padding:"12px 20px", textAlign:"center" }}>
                <button style={{ color:RED, fontWeight:700, fontSize:"0.83rem", textDecoration:"none", background:"none", border:"none", cursor:"pointer" }}>View all notifications</button>
              </div>
            </div>
          )}
        </div>

        {/* Avatar */}
        <div style={{ position:"relative" }}>
          <button onClick={() => { setDropdown(o => !o); setNotifOpen(false); }}
            style={{ width:38, height:38, borderRadius:10, background:`linear-gradient(135deg,${RED},${RED_DK})`, border:"none", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:WHITE, fontWeight:800, fontSize:"0.88rem" }}
          >
            {initials}
          </button>
          {dropdown && (
            <div style={{ position:"absolute", right:0, top:48, width:280, background:WHITE, border:`1px solid ${BORDER}`, borderRadius:16, boxShadow:"0 16px 48px rgba(0,0,0,0.12)", zIndex:300, overflow:"hidden" }}>
              <div style={{ padding:"18px 20px", borderBottom:`1px solid ${BORDER}`, background:SMOKE }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:12 }}>
                  <div style={{ width:44, height:44, borderRadius:12, background:`linear-gradient(135deg,${RED},${RED_DK})`, display:"flex", alignItems:"center", justifyContent:"center", color:WHITE, fontWeight:800, fontSize:"1.1rem" }}>
                    {initials}
                  </div>
                  <div style={{ flex:1 }}>
                    <p style={{ fontWeight:800, color:NAVY2, fontSize:"0.95rem", lineHeight:1.2 }}>{displayName}</p>
                    <span style={{ background:RED_GL, color:RED, fontWeight:700, fontSize:"0.7rem", padding:"3px 10px", borderRadius:12, marginTop:4, display:"inline-block", textTransform:"capitalize" }}>{displayRole.replace("_"," ")}</span>
                  </div>
                </div>
                <p style={{ color:SLATE_L, fontSize:"0.8rem", marginTop:8, wordBreak:"break-all" }}>{profile?.email || user?.primaryEmailAddress?.emailAddress}</p>
              </div>
              
              <div style={{ padding:"8px 0" }}>
                <div onClick={() => navigate("/reports")} style={{ padding:"14px 20px", cursor:"pointer", color:RED, fontSize:"0.88rem", fontWeight:600, display:"flex", alignItems:"center", gap:10, transition:"background 0.15s", background:RED_GL, margin:"8px 12px", borderRadius:10 }}
                  onMouseEnter={e => e.currentTarget.style.background = RED}
                  onMouseLeave={e => e.currentTarget.style.background = RED_GL}
                >
                  <span>📊</span>
                  <span>My Reports</span>
                </div>
                
                {[["👤 My Profile","/profile"],["⚙️ Settings","/settings"]].map(([l,h]) => (
                  <div key={l} onClick={() => navigate(h)} style={{ padding:"14px 20px", cursor:"pointer", color:NAVY2, fontSize:"0.88rem", fontWeight:500, display:"flex", alignItems:"center", gap:10, transition:"background 0.15s" }}
                    onMouseEnter={e => e.currentTarget.style.background = SMOKE}
                    onMouseLeave={e => e.currentTarget.style.background = WHITE}
                  >{l}</div>
                ))}
              </div>
              
              <div style={{ borderTop:`1px solid ${BORDER}`, padding:"12px 20px" }}>
                <div onClick={() => { window.location.href = "/"; }} style={{ color:RED, fontWeight:700, fontSize:"0.88rem", cursor:"pointer", display:"flex", alignItems:"center", gap:8 }}>🏠 Back to Home</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

/* ─────────────────────────────────────────────────
   STAT CARD
───────────────────────────────────────────────── */
function StatCard({ icon, value, label, trend, trendVal, color = RED, delay = 0 }) {
  const [hovered, setHovered] = useState(false);
  const up = trend === "up";
  return (
    <div onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      style={{
        background:WHITE, borderRadius:18, border:`1px solid ${BORDER}`, padding:"24px 22px",
        boxShadow: hovered ? "0 16px 48px rgba(0,0,0,0.1)" : "0 2px 12px rgba(0,0,0,0.04)",
        transform: hovered ? "translateY(-5px)" : "translateY(0)",
        transition:"all 0.3s cubic-bezier(.4,0,.2,1)",
        animationDelay:`${delay}ms`, animation:"fadeUp 0.6s ease both"
      }}
    >
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 }}>
        <div style={{ width:48, height:48, borderRadius:14, background:`${color}14`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.2rem", color }}>
          {icon}
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:4, color: up ? "#16A34A" : RED, fontWeight:700, fontSize:"0.78rem", background: up ? "#DCFCE7" : "#FEE2E2", padding:"3px 8px", borderRadius:20 }}>
          {up ? <FaArrowTrendUp/> : <FaArrowTrendDown/>} {trendVal}
        </div>
      </div>
      <div style={{ fontFamily:FONT, fontWeight:900, fontSize:"2rem", color:NAVY2, lineHeight:1, marginBottom:4 }}>
        <AnimatedCounter target={value}/>
      </div>
      <div style={{ color:SLATE_L, fontSize:"0.82rem", fontWeight:500 }}>{label}</div>
    </div>
  );
}

/* ─────────────────────────────────────────────────
   CARD WRAPPER
───────────────────────────────────────────────── */
function Card({ children, style = {}, title, action }) {
  return (
    <div style={{ background:WHITE, borderRadius:18, border:`1px solid ${BORDER}`, boxShadow:"0 2px 12px rgba(0,0,0,0.04)", overflow:"hidden", ...style }}>
      {title && (
        <div style={{ padding:"18px 22px", borderBottom:`1px solid ${BORDER}`, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <h3 style={{ fontFamily:FONT, fontWeight:800, fontSize:"0.97rem", color:NAVY2 }}>{title}</h3>
          {action && <span style={{ color:RED, fontWeight:700, fontSize:"0.8rem", cursor:"pointer" }}>{action}</span>}
        </div>
      )}
      <div style={{ padding:"18px 22px" }}>{children}</div>
    </div>
  );
}

/* ─────────────────────────────────────────────────
   MINI CHART (pure CSS bars)
───────────────────────────────────────────────── */
function MiniBarChart({ data, color = RED }) {
  const max = Math.max(...data.map(d => d.val));
  return (
    <div style={{ display:"flex", alignItems:"flex-end", gap:6, height:64 }}>
      {data.map(({ label, val }, i) => (
        <div key={i} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
          <div style={{ width:"100%", background:`${color}18`, borderRadius:"4px 4px 0 0", height:52, display:"flex", alignItems:"flex-end" }}>
            <div style={{ width:"100%", background:color, borderRadius:"4px 4px 0 0", height:`${(val/max)*100}%`, transition:"height 1s ease", minHeight:4 }}/>
          </div>
          <span style={{ fontSize:"0.65rem", color:SLATE_L, fontWeight:600 }}>{label}</span>
        </div>
      ))}
    </div>
  );
}

/* ─────────────────────────────────────────────────
   DONUT CHART (SVG)
───────────────────────────────────────────────── */
function DonutChart({ segments }) {
  const total = segments.reduce((s, d) => s + d.val, 0);
  let cumulative = 0;
  const R = 60, cx = 70, cy = 70, r = R - 14;
  const paths = segments.map(({ val, color }) => {
    const startAngle = (cumulative / total) * 360 - 90;
    cumulative += val;
    const endAngle = (cumulative / total) * 360 - 90;
    const start = { x: cx + R * Math.cos(Math.PI * startAngle / 180), y: cy + R * Math.sin(Math.PI * startAngle / 180) };
    const end   = { x: cx + R * Math.cos(Math.PI * endAngle / 180),   y: cy + R * Math.sin(Math.PI * endAngle / 180) };
    const large = endAngle - startAngle > 180 ? 1 : 0;
    return { d:`M ${cx} ${cy} L ${start.x} ${start.y} A ${R} ${R} 0 ${large} 1 ${end.x} ${end.y} Z`, color, pct:Math.round(val/total*100) };
  });
  return (
    <svg width={140} height={140} viewBox="0 0 140 140">
      {paths.map((p, i) => <path key={i} d={p.d} fill={p.color} opacity={0.85}/>)}
      <circle cx={cx} cy={cy} r={r} fill={WHITE}/>
      <text x={cx} y={cy-6} textAnchor="middle" style={{ fontFamily:FONT, fontWeight:900, fontSize:18, fill:NAVY2 }}>{total}</text>
      <text x={cx} y={cy+12} textAnchor="middle" style={{ fontFamily:FONT, fontWeight:500, fontSize:9, fill:SLATE_L }}>Total Units</text>
    </svg>
  );
}

/* ─────────────────────────────────────────────────
   MAIN DASHBOARD
───────────────────────────────────────────────── */
function Dashboard() {
  const { isLoaded: userLoaded, user } = useUser();
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const [profile, setProfile] = useState(null);
  const [theme, setTheme] = useState(() => localStorage.getItem("dashboard-theme") || "light");
  const [collapsed, setCollapsed] = useState(false);
  const [activeNav, setActiveNav] = useState("dashboard");

  const toggleTheme  = () => { const t = theme==="light"?"dark":"light"; setTheme(t); localStorage.setItem("dashboard-theme",t); };
  const toggleSidebar = () => setCollapsed(c => !c);

  useEffect(() => {
    const fetchProfile = async () => {
      if (!userLoaded || !user) return;
      try {
        const r = await fetch(`http://127.0.0.1:5000/api/users/profile/${user.id}`);
        if (r.ok) {
          const data = await r.json();
          console.log("Profile data from API:", data);
          setProfile(data);
          // Update localStorage with API data
          localStorage.setItem("userFullName", data.fullName || "");
          localStorage.setItem("userEmail", data.email || "");
          localStorage.setItem("userRole", data.role || "donor");
        } else {
          console.error("Profile fetch failed:", r.status);
          // Fallback to localStorage
          const storedName = localStorage.getItem("userFullName");
          const storedEmail = localStorage.getItem("userEmail");
          const storedRole = localStorage.getItem("userRole");
          if (storedName || storedEmail || storedRole) {
            console.log("Using localStorage fallback:", { storedName, storedEmail, storedRole });
            setProfile({
              fullName: storedName || user?.fullName || "",
              email: storedEmail || user?.primaryEmailAddress?.emailAddress || "",
              role: storedRole || "donor"
            });
          } else {
            // Final fallback to Clerk user data
            console.log("Using Clerk user data as final fallback");
            const clerkName = user?.fullName || `${user?.firstName || ""} ${user?.lastName || ""}`.trim() || "User";
            setProfile({
              fullName: clerkName,
              email: user?.primaryEmailAddress?.emailAddress || "",
              role: "donor"
            });
            localStorage.setItem("userFullName", clerkName);
            localStorage.setItem("userEmail", user?.primaryEmailAddress?.emailAddress || "");
            localStorage.setItem("userRole", "donor");
          }
        }
      } catch (e) { 
        console.error("Profile fetch error:", e);
        // Fallback to localStorage if API fails
        const storedName = localStorage.getItem("userFullName");
        const storedEmail = localStorage.getItem("userEmail");
        const storedRole = localStorage.getItem("userRole");
        if (storedName || storedEmail || storedRole) {
          console.log("Using localStorage fallback (catch):", { storedName, storedEmail, storedRole });
          setProfile({
            fullName: storedName || user?.fullName || "",
            email: storedEmail || user?.primaryEmailAddress?.emailAddress || "",
            role: storedRole || "donor"
          });
        } else {
          // Final fallback to Clerk user data
          console.log("Using Clerk user data as final fallback (catch)");
          const clerkName = user?.fullName || `${user?.firstName || ""} ${user?.lastName || ""}`.trim() || "User";
          setProfile({
            fullName: clerkName,
            email: user?.primaryEmailAddress?.emailAddress || "",
            role: "donor"
          });
          localStorage.setItem("userFullName", clerkName);
          localStorage.setItem("userEmail", user?.primaryEmailAddress?.emailAddress || "");
          localStorage.setItem("userRole", "donor");
        }
      }
    };
    fetchProfile();
  }, [user, userLoaded]);

  const handleLogout = async () => { await signOut(); navigate("/login"); };
  const handleNavigate = (path) => { setActiveNav(path.replace("/","")); navigate(path); };

  if (!userLoaded) return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", minHeight:"100vh", fontFamily:FONT, gap:12, background:SMOKE }}>
      <div style={{ width:48, height:48, borderRadius:"50%", border:`3px solid ${BORDER}`, borderTopColor:RED, animation:"spin 0.9s linear infinite" }}/>
      <style>{"@keyframes spin{to{transform:rotate(360deg)}}"}</style>
      <p style={{ color:SLATE_L, fontWeight:600 }}>Loading operations console…</p>
    </div>
  );

  const displayName = profile?.fullName || user?.fullName || "User";
  const displayRole = profile?.role || "donor";

  const sidebarW = collapsed ? 68 : SIDEBAR_W;

  /* mock data */
  const bloodInventory = [
    { group:"O+",  units:124, status:"Available", pct:88 },
    { group:"A+",  units:89,  status:"Available", pct:75 },
    { group:"B+",  units:42,  status:"Low Stock",  pct:38 },
    { group:"AB+", units:67,  status:"Available", pct:58 },
    { group:"A-",  units:31,  status:"Low Stock",  pct:26 },
    { group:"O-",  units:5,   status:"Critical",  pct:8  },
    { group:"B-",  units:15,  status:"Low Stock",  pct:13 },
    { group:"AB-", units:8,   status:"Critical",  pct:7  },
  ];

  const emergencyRequests = [
    { patient:"Rahul Patel",   group:"O-",  units:2, hospital:"Apollo",   status:"Pending",    time:"2m ago" },
    { patient:"Priya Sharma",  group:"B+",  units:1, hospital:"Fortis",   status:"Approved",   time:"18m ago" },
    { patient:"Amit Shah",     group:"A+",  units:3, hospital:"AIIMS",    status:"Dispatched", time:"45m ago" },
    { patient:"Sunita Kumari", group:"AB-", units:1, hospital:"Narayana", status:"Completed",  time:"2h ago" },
  ];

  const activities = [
    { dot:RED,      text:"Emergency O- request submitted",   sub:"Rahul Patel · Apollo Mumbai",    time:"2m ago"  },
    { dot:"#2563EB",text:"New donor registered",             sub:"Kavita Desai · A+ · Pune",       time:"18m ago" },
    { dot:"#16A34A",text:"Donor intake completed",           sub:"Vikram Singh · B+ · 450ml",      time:"45m ago" },
    { dot:"#7C3AED",text:"Appointment scheduled",           sub:"Dr. Mehta · July 18, 10:00 AM",  time:"1h ago"  },
    { dot:"#D97706",text:"Inventory threshold alert",       sub:"O- below 10 units",               time:"2h ago"  },
    { dot:"#64748B",text:"Monthly report generated",        sub:"June 2026 — 1,240 donations",    time:"3h ago"  },
  ];

  const weeklyData = [
    { label:"Mon", val:28 }, { label:"Tue", val:42 }, { label:"Wed", val:35 },
    { label:"Thu", val:58 }, { label:"Fri", val:49 }, { label:"Sat", val:67 }, { label:"Sun", val:31 },
  ];

  const donutSegs = [
    { val:124, color:"#C41230" }, { val:89, color:"#16A34A" }, { val:67, color:"#7C3AED" },
    { val:42, color:"#2563EB" }, { val:31, color:"#D97706" }, { val:28, color:"#0891B2" },
  ];

  return (
    <div style={{ fontFamily:FONT, background:SMOKE, minHeight:"100vh" }}>
      {/* Global keyframes */}
      <style>{`
        @keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
        @keyframes spin{to{transform:rotate(360deg)}}
        *,:before,:after{box-sizing:border-box;}
        ::-webkit-scrollbar{width:6px;}
        ::-webkit-scrollbar-track{background:${SMOKE};}
        ::-webkit-scrollbar-thumb{background:${BORDER};border-radius:3px;}
        ::-webkit-scrollbar-thumb:hover{background:${SLATE_L};}
        .dash-main-grid{display:grid;grid-template-columns:2fr 1fr;gap:20px;}
        .dash-inv-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
        @media(max-width:1100px){.dash-main-grid{grid-template-columns:1fr!important;}}
        @media(max-width:640px){.dash-inv-grid{grid-template-columns:1fr!important;}}
      `}</style>

      {/* Sidebar */}
      <Sidebar active={activeNav} navigate={handleNavigate} onLogout={handleLogout} collapsed={collapsed}/>

      {/* Topbar */}
      <Topbar
        displayName={displayName} displayRole={displayRole} user={user} profile={profile}
        theme={theme} toggleTheme={toggleTheme}
        sidebarCollapsed={collapsed} toggleSidebar={toggleSidebar}
      />

      {/* Main scroll area */}
      <main style={{ marginLeft:sidebarW, marginTop:72, padding:"28px 28px 48px", transition:"margin-left 0.3s cubic-bezier(.4,0,.2,1)" }}>

        {/* ── URGENT BANNER ── */}
        <div style={{ background:`linear-gradient(135deg,${RED_DK},${RED})`, borderRadius:14, padding:"14px 22px", marginBottom:24, display:"flex", alignItems:"center", justifyContent:"space-between", boxShadow:`0 8px 24px ${RED}30` }}>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <span style={{ fontSize:"1.2rem" }}>🚨</span>
            <span style={{ color:WHITE, fontWeight:700, fontSize:"0.9rem" }}>2 critical emergency requests require immediate attention</span>
          </div>
          <button style={{ background:"rgba(255,255,255,0.2)", border:"none", borderRadius:8, padding:"7px 16px", color:WHITE, fontWeight:700, fontSize:"0.83rem", cursor:"pointer", backdropFilter:"blur(4px)" }}>View Requests →</button>
        </div>

        {/* ── STAT CARDS ── */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:18, marginBottom:24 }}
          className="stats-row"
        >
          <style>{`@media(max-width:900px){.stats-row{grid-template-columns:1fr 1fr!important;}}@media(max-width:480px){.stats-row{grid-template-columns:1fr!important;}}`}</style>
          <StatCard icon={<FaUsers/>}            value={12840} label="Registered Donors"    trend="up"   trendVal="+12%" color="#2563EB" delay={0}  />
          <StatCard icon={<FaDroplet/>}           value={385}   label="Blood Units Available" trend="down" trendVal="-5%"  color={RED}     delay={80} />
          <StatCard icon={<FaHeartPulse/>}        value={248}   label="Active Requests"       trend="up"   trendVal="+8%"  color="#7C3AED" delay={160}/>
          <StatCard icon={<FaHandHoldingMedical/>}value={12300} label="Lives Saved"           trend="up"   trendVal="+21%" color="#16A34A" delay={240}/>
        </div>

        {/* ── MAIN GRID ── */}
        <div className="dash-main-grid" style={{ marginBottom:20 }}>

          {/* Blood Inventory */}
          <Card title="Blood Inventory" action="Manage Stock →">
            <div className="dash-inv-grid">
              {bloodInventory.map(({ group, units, status, pct }) => {
                const sc = status==="Critical"?RED:status==="Low Stock"?"#D97706":"#16A34A";
                return (
                  <div key={group} style={{ background:SMOKE, borderRadius:12, padding:"14px 14px", border:`1px solid ${BORDER}` }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                      <BloodBadge group={group}/>
                      <StatusPill status={status}/>
                    </div>
                    <div style={{ fontWeight:900, fontSize:"1.5rem", color:NAVY2, lineHeight:1, marginBottom:6 }}>{units}</div>
                    <div style={{ height:5, background:BORDER, borderRadius:3 }}>
                      <div style={{ height:"100%", width:`${pct}%`, background:sc, borderRadius:3, transition:"width 1.5s ease" }}/>
                    </div>
                    <div style={{ color:SLATE_L, fontSize:"0.72rem", marginTop:4 }}>units available</div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Charts column */}
          <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
            {/* Weekly donations */}
            <Card title="Weekly Donations">
              <MiniBarChart data={weeklyData} color={RED}/>
              <div style={{ display:"flex", justifyContent:"space-between", marginTop:12 }}>
                <span style={{ color:SLATE_L, fontSize:"0.78rem" }}>This Week</span>
                <span style={{ fontWeight:700, color:NAVY2, fontSize:"0.85rem" }}>310 donations</span>
              </div>
            </Card>

            {/* Inventory donut */}
            <Card title="Inventory Distribution">
              <div style={{ display:"flex", alignItems:"center", gap:16 }}>
                <DonutChart segments={donutSegs}/>
                <div style={{ flex:1 }}>
                  {bloodInventory.slice(0,6).map(({ group, units }) => (
                    <div key={group} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                        <div style={{ width:8, height:8, borderRadius:"50%", background:BG_COLOR[group]||RED }}/>
                        <span style={{ fontSize:"0.78rem", color:SLATE_L, fontWeight:600 }}>{group}</span>
                      </div>
                      <span style={{ fontSize:"0.78rem", fontWeight:700, color:NAVY2 }}>{units}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* ── DEMAND MODEL ── */}
        <Card title="AI Blood Demand Forecast" action="Full Report →" style={{ marginBottom:20 }}>
          <p style={{ color:SLATE_L, fontSize:"0.83rem", marginBottom:16 }}>Predicted shortfalls for next 7 days based on historical patterns and scheduled surgeries.</p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}
            className="demand-grid">
            <style>{`@media(max-width:640px){.demand-grid{grid-template-columns:1fr 1fr!important;}}`}</style>
            {[["O+",90,"#C41230","500 units"],["A+",65,"#16A34A","320 units"],["B+",50,"#2563EB","250 units"],["AB+",25,"#7C3AED","100 units"]].map(([g,pct,c,req]) => (
              <div key={g} style={{ background:SMOKE, borderRadius:12, padding:"16px 14px", border:`1px solid ${BORDER}` }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                  <BloodBadge group={g}/>
                  <span style={{ fontWeight:800, fontSize:"1.1rem", color:NAVY2 }}>{pct}%</span>
                </div>
                <div style={{ height:6, background:BORDER, borderRadius:3, marginBottom:8 }}>
                  <div style={{ height:"100%", width:`${pct}%`, background:c, borderRadius:3, transition:"width 1.5s" }}/>
                </div>
                <span style={{ color:SLATE_L, fontSize:"0.75rem" }}>{req} needed</span>
              </div>
            ))}
          </div>
        </Card>

        {/* ── EMERGENCY TABLE & QUICK ACTIONS ── */}
        <div className="dash-main-grid" style={{ marginBottom:20 }}>

          <Card title="Live Emergency Requests" action="View All →">
            <div style={{ overflowX:"auto" }}>
              <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"0.85rem" }}>
                <thead>
                  <tr style={{ borderBottom:`1px solid ${BORDER}` }}>
                    {["Patient","Blood","Units","Hospital","Status","Time"].map(h => (
                      <th key={h} style={{ padding:"8px 10px", textAlign:"left", color:SLATE_L, fontWeight:700, fontSize:"0.75rem", letterSpacing:"0.04em", whiteSpace:"nowrap" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {emergencyRequests.map(({ patient, group, units, hospital, status, time }, i) => (
                    <tr key={i} style={{ borderBottom:`1px solid ${BORDER}` }}
                      onMouseEnter={e => e.currentTarget.style.background = SMOKE}
                      onMouseLeave={e => e.currentTarget.style.background = WHITE}
                    >
                      <td style={{ padding:"12px 10px", fontWeight:700, color:NAVY2 }}>{patient}</td>
                      <td style={{ padding:"12px 10px" }}><BloodBadge group={group}/></td>
                      <td style={{ padding:"12px 10px", color:SLATE, fontWeight:600 }}>{units}u</td>
                      <td style={{ padding:"12px 10px", color:SLATE_L }}>{hospital}</td>
                      <td style={{ padding:"12px 10px" }}><StatusPill status={status}/></td>
                      <td style={{ padding:"12px 10px", color:SLATE_L, fontSize:"0.78rem" }}>{time}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* Quick Actions */}
          <Card title="Quick Actions">
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {[
                { icon:"➕", label:"Add New Patient",   bg:`linear-gradient(135deg,${RED},${RED_DK})`,     color:WHITE },
                { icon:"🩸", label:"Register Donor",    bg:`linear-gradient(135deg,#2563EB,#1D4ED8)`,      color:WHITE },
                { icon:"🚨", label:"Emergency Request", bg:`linear-gradient(135deg,#D97706,#B45309)`,      color:WHITE },
                { icon:"📋", label:"Generate Report",   bg:"transparent",                                  color:SLATE, border:`1px solid ${BORDER}` },
                { icon:"📅", label:"Schedule Appointment",bg:"transparent",                               color:SLATE, border:`1px solid ${BORDER}` },
              ].map(({ icon, label, bg, color, border }) => (
                <button key={label} style={{ display:"flex", alignItems:"center", gap:12, padding:"13px 16px", background:bg, color, border:border||"none", borderRadius:12, fontFamily:FONT, fontWeight:700, fontSize:"0.88rem", cursor:"pointer", transition:"all 0.2s", textAlign:"left" }}
                  onMouseEnter={e => { e.currentTarget.style.opacity = "0.85"; e.currentTarget.style.transform = "translateX(4px)"; }}
                  onMouseLeave={e => { e.currentTarget.style.opacity = "1"; e.currentTarget.style.transform = "translateX(0)"; }}
                >
                  <span style={{ fontSize:"1rem" }}>{icon}</span>{label}
                </button>
              ))}
            </div>
          </Card>
        </div>

        {/* ── ACTIVITY FEED ── */}
        <Card title="Recent System Activity" action="View All →">
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:0 }} className="activity-grid">
            <style>{`@media(max-width:640px){.activity-grid{grid-template-columns:1fr!important;}}`}</style>
            {activities.map(({ dot, text, sub, time }, i) => (
              <div key={i} style={{ display:"flex", gap:14, padding:"14px 16px", borderBottom: i<activities.length-2?`1px solid ${BORDER}`:"none", cursor:"pointer", transition:"background 0.15s", borderRadius:10 }}
                onMouseEnter={e => e.currentTarget.style.background = SMOKE}
                onMouseLeave={e => e.currentTarget.style.background = WHITE}
              >
                <div style={{ width:10, height:10, borderRadius:"50%", background:dot, flexShrink:0, marginTop:5, boxShadow:`0 0 0 3px ${dot}25` }}/>
                <div style={{ flex:1 }}>
                  <p style={{ fontWeight:700, color:NAVY2, fontSize:"0.85rem", lineHeight:1.4 }}>{text}</p>
                  <p style={{ color:SLATE_L, fontSize:"0.78rem", marginTop:2 }}>{sub}</p>
                </div>
                <span style={{ color:SLATE_L, fontSize:"0.75rem", whiteSpace:"nowrap", flexShrink:0 }}>{time}</span>
              </div>
            ))}
          </div>
        </Card>

      </main>
    </div>
  );
}

export default Dashboard;