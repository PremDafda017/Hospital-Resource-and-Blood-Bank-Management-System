import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
    FaUsers,
    FaUserDoctor,
    FaDroplet,
    FaHeartPulse,
    FaBell,
    FaRightFromBracket,
    FaChartLine,
    FaGear,
    FaCalendarDays,
    FaHandHoldingMedical,
    FaSun,
    FaMoon,
    FaUser,
    FaArrowLeft,
    FaClipboardList,
    FaCircleCheck,
    FaCircleInfo,
    FaNotesMedical,
} from "react-icons/fa6";
import { useAuth, useUser } from "@clerk/clerk-react";
import "../Dashboard.css";

function AddAppointment() {
    const { isLoaded: userLoaded, user } = useUser();
    const { signOut } = useAuth();
    const navigate = useNavigate();
    const [theme, setTheme] = useState(() => localStorage.getItem("dashboard-theme") || "light");
    const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState(false);

    const [formData, setFormData] = useState({
        patientId: "",
        doctorId: "",
        date: "",
        time: "",
        type: "Check-up",
        notes: "",
    });

    const toggleTheme = () => {
        const newTheme = theme === "light" ? "dark" : "light";
        setTheme(newTheme);
        localStorage.setItem("dashboard-theme", newTheme);
    };

    const handleLogout = async () => {
        await signOut();
        navigate("/login");
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setSuccess(false);
        setLoading(true);

        if (!formData.patientId || !formData.doctorId || !formData.date || !formData.time) {
            setError("Please fill in all required fields");
            setLoading(false);
            return;
        }

        const patients = { "1": "John Smith", "2": "Mary Johnson", "3": "Robert Davis", "4": "Sarah Williams" };
        const doctors = { "1": "Dr. Sarah Johnson", "2": "Dr. Michael Chen", "3": "Dr. Emily Wilson" };

        const newAppointment = {
            id: Date.now(),
            patient: patients[formData.patientId] || "Unknown Patient",
            doctor: doctors[formData.doctorId] || "Unknown Doctor",
            date: formData.date,
            time: formData.time,
            type: formData.type,
            notes: formData.notes,
            status: "Scheduled",
        };

        const existing = JSON.parse(localStorage.getItem("appointments") || "[]");
        localStorage.setItem("appointments", JSON.stringify([newAppointment, ...existing]));

        await new Promise((r) => setTimeout(r, 500));
        setSuccess(true);
        setLoading(false);
        setTimeout(() => navigate("/appointments"), 1500);
    };

    if (!userLoaded) {
        return (
            <div className={`dashboard-loader-container theme-${theme}`}>
                <span className="btn-spinner" />
                <p>Initializing Appointments Hub…</p>
            </div>
        );
    }

    const displayName = user?.fullName || "User";
    const displayRole = "donor";
    const appointmentTypes = ["Check-up", "Follow-up", "Consultation", "Emergency"];

    const inputStyle = {
        width: "100%",
        padding: "10px 14px",
        background: "var(--table-header-bg)",
        border: "1px solid var(--card-border)",
        borderRadius: "var(--r-sm)",
        color: "var(--text-h)",
        fontFamily: "var(--font-body)",
        fontSize: "0.9rem",
        outline: "none",
        boxSizing: "border-box",
    };

    const labelStyle = {
        fontSize: "0.85rem",
        fontWeight: 600,
        color: "var(--text-h)",
        marginBottom: "6px",
        display: "block",
    };

    return (
        <div className={`dashboard-container theme-${theme}`}>

            {/* Sidebar */}
            <aside className="sidebar">
                <div className="logo">
                    <span className="logo-icon"><FaDroplet /></span>
                    <span className="logo-text">HRBMS</span>
                </div>

                <nav className="sidebar-nav">
                    <ul>
                        <li onClick={() => navigate("/dashboard")} style={{ cursor: "pointer" }}>
                            <FaChartLine className="nav-icon" /><span>Dashboard</span>
                        </li>
                        <li onClick={() => navigate("/patients")} style={{ cursor: "pointer" }}>
                            <FaUsers className="nav-icon" /><span>Patients</span>
                        </li>
                        <li onClick={() => navigate("/doctors")} style={{ cursor: "pointer" }}>
                            <FaUserDoctor className="nav-icon" /><span>Doctors</span>
                        </li>
                        <li onClick={() => navigate("/donors")} style={{ cursor: "pointer" }}>
                            <FaHandHoldingMedical className="nav-icon" /><span>Donors</span>
                        </li>
                        <li onClick={() => navigate("/blood-inventory")} style={{ cursor: "pointer" }}>
                            <FaDroplet className="nav-icon" /><span>Blood Inventory</span>
                        </li>
                        <li onClick={() => navigate("/blood-requests")} style={{ cursor: "pointer" }}>
                            <FaHeartPulse className="nav-icon" /><span>Blood Requests</span>
                        </li>
                        <li className="active" onClick={() => navigate("/appointments")} style={{ cursor: "pointer" }}>
                            <FaCalendarDays className="nav-icon" /><span>Appointments</span>
                        </li>
                        <li onClick={() => navigate("/reports")} style={{ cursor: "pointer" }}>
                            <FaClipboardList className="nav-icon" /><span>Reports</span>
                        </li>
                        <li onClick={() => navigate("/settings")} style={{ cursor: "pointer" }}>
                            <FaGear className="nav-icon" /><span>Settings</span>
                        </li>
                        <li onClick={handleLogout} className="logout-item" style={{ cursor: "pointer" }}>
                            <FaRightFromBracket className="nav-icon" /><span>Sign Out</span>
                        </li>
                    </ul>
                </nav>
            </aside>

            {/* Main Content */}
            <main className="dashboard-main">

                {/* Header */}
                <header className="dashboard-header">
                    <div className="header-left">
                        <button
                            onClick={() => navigate("/appointments")}
                            style={{
                                display: "inline-flex", alignItems: "center", gap: "8px",
                                background: "transparent", border: "1px solid var(--card-border)",
                                color: "var(--text-b)", padding: "7px 14px", borderRadius: "var(--r-sm)",
                                fontFamily: "var(--font-body)", fontSize: "0.85rem", fontWeight: 600,
                                cursor: "pointer", marginBottom: "12px", transition: "all 0.15s",
                            }}
                        >
                            <FaArrowLeft /> Back to Appointments
                        </button>
                        <h1>Schedule Appointment</h1>
                        <p>Create a new patient appointment</p>
                    </div>
                    <div className="header-right">
                        <button onClick={toggleTheme} className="theme-toggle-btn" aria-label="Toggle theme">
                            {theme === "light" ? <FaMoon /> : <FaSun />}
                        </button>
                        <div className="notification-wrapper">
                            <FaBell className="notification-icon" />
                            <span className="notification-indicator" />
                        </div>
                        <div className="profile-menu-container">
                            <button
                                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                                className="profile-avatar-btn"
                                aria-label="User profile"
                            >
                                {user?.firstName ? (
                                    <span className="avatar-initials">
                                        {user.firstName.charAt(0)}{user.lastName?.charAt(0) || ""}
                                    </span>
                                ) : (
                                    <FaUser />
                                )}
                            </button>

                            {profileDropdownOpen && (
                                <div className="profile-dropdown">
                                    <div className="profile-dropdown-header">
                                        <h4>{displayName}</h4>
                                        <p>{user?.primaryEmailAddress?.emailAddress}</p>
                                    </div>
                                    <div className="profile-dropdown-body">
                                        <div className="profile-detail-item">
                                            <span>Role</span>
                                            <strong className="role-badge" style={{ margin: 0 }}>{displayRole.replace("_", " ")}</strong>
                                        </div>
                                    </div>
                                    <div className="profile-dropdown-footer">
                                        <button onClick={handleLogout} className="dropdown-logout-btn">
                                            <FaRightFromBracket /><span>Sign Out</span>
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </header>

                {/* Alerts */}
                {error && (
                    <div style={{
                        display: "flex", alignItems: "center", gap: "12px", padding: "14px 18px",
                        borderRadius: "var(--r-md)", background: "rgba(244,63,94,0.08)",
                        border: "1px solid rgba(244,63,94,0.25)", color: "#F43F5E",
                        marginBottom: "24px", fontSize: "0.9rem",
                    }}>
                        <FaCircleInfo /><span>{error}</span>
                    </div>
                )}
                {success && (
                    <div style={{
                        display: "flex", alignItems: "center", gap: "12px", padding: "14px 18px",
                        borderRadius: "var(--r-md)", background: "rgba(52,211,153,0.08)",
                        border: "1px solid rgba(52,211,153,0.25)", color: "#34D399",
                        marginBottom: "24px", fontSize: "0.9rem",
                    }}>
                        <FaCircleCheck /><span>Appointment scheduled successfully! Redirecting…</span>
                    </div>
                )}

                {/* Form */}
                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "24px", maxWidth: "900px" }}>

                    {/* Patient & Doctor */}
                    <div className="card" style={{ padding: "28px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "6px" }}>
                            <FaUser style={{ fontSize: "1.2rem", color: "var(--blue-600)" }} />
                            <h2 style={{ margin: 0 }}>Patient & Doctor</h2>
                        </div>
                        <p style={{ fontSize: "0.85rem", color: "var(--text-b)", marginBottom: "24px" }}>Select patient and attending doctor</p>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
                            <div>
                                <label style={labelStyle}>Patient *</label>
                                <select value={formData.patientId} onChange={(e) => setFormData({ ...formData, patientId: e.target.value })} required style={inputStyle}>
                                    <option value="">Select Patient</option>
                                    <option value="1">John Smith</option>
                                    <option value="2">Mary Johnson</option>
                                    <option value="3">Robert Davis</option>
                                    <option value="4">Sarah Williams</option>
                                </select>
                            </div>
                            <div>
                                <label style={labelStyle}>Doctor *</label>
                                <select value={formData.doctorId} onChange={(e) => setFormData({ ...formData, doctorId: e.target.value })} required style={inputStyle}>
                                    <option value="">Select Doctor</option>
                                    <option value="1">Dr. Sarah Johnson</option>
                                    <option value="2">Dr. Michael Chen</option>
                                    <option value="3">Dr. Emily Wilson</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    {/* Date & Time */}
                    <div className="card" style={{ padding: "28px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "6px" }}>
                            <FaCalendarDays style={{ fontSize: "1.2rem", color: "var(--blue-600)" }} />
                            <h2 style={{ margin: 0 }}>Date & Time</h2>
                        </div>
                        <p style={{ fontSize: "0.85rem", color: "var(--text-b)", marginBottom: "24px" }}>Schedule the appointment slot</p>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px" }}>
                            <div>
                                <label style={labelStyle}>Date *</label>
                                <input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} required style={inputStyle} />
                            </div>
                            <div>
                                <label style={labelStyle}>Time *</label>
                                <input type="time" value={formData.time} onChange={(e) => setFormData({ ...formData, time: e.target.value })} required style={inputStyle} />
                            </div>
                        </div>
                    </div>

                    {/* Appointment Details */}
                    <div className="card" style={{ padding: "28px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "6px" }}>
                            <FaNotesMedical style={{ fontSize: "1.2rem", color: "var(--blue-600)" }} />
                            <h2 style={{ margin: 0 }}>Appointment Details</h2>
                        </div>
                        <p style={{ fontSize: "0.85rem", color: "var(--text-b)", marginBottom: "24px" }}>Type and any additional notes</p>
                        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                            <div>
                                <label style={labelStyle}>Appointment Type *</label>
                                <select value={formData.type} onChange={(e) => setFormData({ ...formData, type: e.target.value })} style={inputStyle}>
                                    {appointmentTypes.map((t) => <option key={t} value={t}>{t}</option>)}
                                </select>
                            </div>
                            <div>
                                <label style={labelStyle}>Notes</label>
                                <textarea
                                    value={formData.notes}
                                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                                    rows={4}
                                    placeholder="Any additional notes or special requirements…"
                                    style={{ ...inputStyle, resize: "vertical" }}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Actions */}
                    <div style={{ display: "flex", gap: "12px", justifyContent: "flex-end" }}>
                        <button
                            type="button"
                            onClick={() => navigate("/appointments")}
                            disabled={loading}
                            className="action-btn-outline"
                            style={{ padding: "11px 24px", fontSize: "0.9rem" }}
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={loading}
                            className="action-btn"
                            style={{ padding: "11px 24px", fontSize: "0.9rem" }}
                        >
                            {loading ? "Scheduling…" : "Schedule Appointment"}
                        </button>
                    </div>

                </form>
            </main>
        </div>
    );
}

export default AddAppointment;
