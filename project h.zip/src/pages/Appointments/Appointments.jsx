import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
    FaCalendarDays,
    FaPlus,
    FaMagnifyingGlass,
    FaClock,
    FaCircleXmark,
    FaEye,
} from "react-icons/fa6";
import DashboardLayout from '../../components/DashboardLayout';
import { StatusPill } from '../../components/DashboardLayout';

/* Design Tokens matching Dashboard */
const FONT = "'Inter','Segoe UI',system-ui,sans-serif";
const RED = "#C41230";
const RED_DK = "#8B0000";
const RED_GL = "rgba(196,18,48,0.12)";
const NAVY = "#0F172A";
const NAVY2 = "#1E293B";
const SLATE = "#334155";
const SLATE_L = "#64748B";
const BORDER = "#E2E8F0";
const SMOKE = "#F8FAFC";
const WHITE = "#FFFFFF";

// Sample static data for appointments
const MOCK_APPOINTMENTS = [
    { id: 1, patient: "John Smith", doctor: "Dr. Sarah Johnson", date: "2024-01-25", time: "10:00 AM", type: "Check-up", status: "Scheduled" },
    { id: 2, patient: "Mary Johnson", doctor: "Dr. Michael Chen", date: "2024-01-26", time: "2:30 PM", type: "Follow-up", status: "Scheduled" },
    { id: 3, patient: "Robert Davis", doctor: "Dr. Emily Wilson", date: "2024-01-27", time: "11:00 AM", type: "Consultation", status: "Completed" },
    { id: 4, patient: "Sarah Williams", doctor: "Dr. James Brown", date: "2024-01-28", time: "3:00 PM", type: "Emergency", status: "Scheduled" },
    { id: 5, patient: "Michael Brown", doctor: "Dr. Lisa Thompson", date: "2024-01-29", time: "9:30 AM", type: "Check-up", status: "Cancelled" },
];

const getStatusColor = (status) => {
    switch (status) {
        case 'Scheduled': return '#D97706';
        case 'Completed': return '#16A34A';
        case 'Cancelled': return RED;
        default: return SLATE_L;
    }
};

const getTypeColor = (type) => {
    const colors = { "Check-up": "#2563EB", "Follow-up": "#34D399", Consultation: "#A855F7", Emergency: RED };
    return colors[type] || SLATE_L;
};

function Appointments() {
    const navigate = useNavigate();
    const [appointments, setAppointments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState("");
    const [filterStatus, setFilterStatus] = useState("all");
    const [filterType, setFilterType] = useState("all");

    useEffect(() => {
        setTimeout(() => {
            const stored = localStorage.getItem("appointments");
            if (stored) {
                setAppointments(JSON.parse(stored));
            } else {
                localStorage.setItem("appointments", JSON.stringify(MOCK_APPOINTMENTS));
                setAppointments(MOCK_APPOINTMENTS);
            }
            setLoading(false);
        }, 500);
    }, []);

    const handleDelete = (id) => {
        if (window.confirm("Are you sure you want to delete this appointment?")) {
            const updated = appointments.filter((a) => a.id !== id);
            setAppointments(updated);
            localStorage.setItem("appointments", JSON.stringify(updated));
        }
    };

    if (loading) {
        return (
            <DashboardLayout activeTab="appointments" title="Appointments" subtitle="Manage patient appointments and schedules">
                <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', minHeight:300, gap:12 }}>
                    <div style={{ width:48, height:48, borderRadius:'50%', border:`3px solid ${BORDER}`, borderTopColor:RED, animation:'spin 0.9s linear infinite' }} />
                    <style>{"@keyframes spin{to{transform:rotate(360deg)}}"}</style>
                    <p style={{ color:SLATE_L, fontWeight:600 }}>Loading appointments...</p>
                </div>
            </DashboardLayout>
        );
    }

    const filteredAppointments = appointments.filter((a) => {
        const matchSearch =
            a.patient.toLowerCase().includes(searchQuery.toLowerCase()) ||
            a.doctor.toLowerCase().includes(searchQuery.toLowerCase());
        const matchStatus = filterStatus === "all" || a.status === filterStatus;
        const matchType = filterType === "all" || a.type === filterType;
        return matchSearch && matchStatus && matchType;
    });

    const statuses = ["Scheduled", "Completed", "Cancelled"];
    const types = ["Check-up", "Follow-up", "Consultation", "Emergency"];

    return (
        <DashboardLayout activeTab="appointments" title="Appointments" subtitle="Manage patient appointments and schedules">
            <div style={{ fontFamily:FONT }}>
                {/* Page Header */}
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:28 }}>
                    <h2 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.5rem', color:SLATE, lineHeight:1.2 }}>Appointments Database</h2>
                    <button 
                        onClick={() => navigate("/appointments/add")}
                        style={{ 
                            background:`linear-gradient(135deg,${RED},${RED_DK})`,
                            color:WHITE, border:'none', borderRadius:12, padding:'12px 24px',
                            fontFamily:FONT, fontSize:'0.9rem', fontWeight:700, cursor:'pointer',
                            display:'flex', alignItems:'center', gap:8,
                            boxShadow:`0 4px 16px ${RED_GL}`,
                            transition:'all 0.25s'
                        }}
                        onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = `0 8px 24px ${RED_GL}`; }}
                        onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = `0 4px 16px ${RED_GL}`; }}
                    >
                        <FaPlus /> Schedule New
                    </button>
                </div>

                {/* Filters */}
                <div style={{ display:'flex', gap:16, marginBottom:28 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10, background:SMOKE, border:`1px solid ${BORDER}`, borderRadius:14, padding:'10px 16px', flex:1, maxWidth:400 }}>
                        <FaMagnifyingGlass style={{ color:SLATE_L, fontSize:'0.95rem' }} />
                        <input
                            type="text"
                            placeholder="Search patient or doctor…"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            style={{ border:'none', background:'transparent', fontFamily:FONT, fontSize:'0.9rem', color:SLATE, outline:'none', width:'100%' }}
                        />
                    </div>
                    <select
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value)}
                        style={{ padding:'10px 16px', borderRadius:14, border:`1px solid ${BORDER}`, fontFamily:FONT, fontSize:'0.9rem', color:SLATE, outline:'none', background:SMOKE, cursor:'pointer' }}
                    >
                        <option value="all">All Statuses</option>
                        {statuses.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <select
                        value={filterType}
                        onChange={(e) => setFilterType(e.target.value)}
                        style={{ padding:'10px 16px', borderRadius:14, border:`1px solid ${BORDER}`, fontFamily:FONT, fontSize:'0.9rem', color:SLATE, outline:'none', background:SMOKE, cursor:'pointer' }}
                    >
                        <option value="all">All Types</option>
                        {types.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>

                {/* Appointments Grid */}
                <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(380px,1fr))', gap:20 }}>
                    {filteredAppointments.length > 0 ? (
                        filteredAppointments.map((apt) => (
                            <div key={apt.id} style={{
                                background:WHITE, borderRadius:20, border:`1px solid ${BORDER}`,
                                padding:24, boxShadow:'0 4px 20px rgba(0,0,0,0.06)',
                                transition:'all 0.3s'
                            }}
                                onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 20px 60px rgba(0,0,0,0.12)'; }}
                                onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.06)'; }}
                            >
                                {/* Header */}
                                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
                                    <div style={{ 
                                        width:56, height:56, borderRadius:16, 
                                        background:getTypeColor(apt.type),
                                        display:'flex', alignItems:'center', justifyContent:'center',
                                        color:WHITE, fontSize:'1.4rem'
                                    }}>
                                        <FaCalendarDays />
                                    </div>
                                    <StatusPill status={apt.status} />
                                </div>

                                {/* Info */}
                                <div style={{ marginBottom:16 }}>
                                    <h3 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.1rem', color:SLATE, lineHeight:1.2, marginBottom:8 }}>{apt.patient}</h3>
                                    <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'0.85rem', color:SLATE, marginBottom:4 }}>
                                        <span>👨‍⚕️</span>
                                        <span>{apt.doctor}</span>
                                    </div>
                                    <div style={{ display:'flex', gap:16, fontSize:'0.85rem', color:SLATE }}>
                                        <span style={{ display:'flex', alignItems:'center', gap:6 }}><FaCalendarDays style={{ color:SLATE_L }} /> {apt.date}</span>
                                        <span style={{ display:'flex', alignItems:'center', gap:6 }}><FaClock style={{ color:SLATE_L }} /> {apt.time}</span>
                                    </div>
                                </div>

                                {/* Type Badge */}
                                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'12px 16px', background:SMOKE, borderRadius:14, marginBottom:16 }}>
                                    <span style={{ fontFamily:FONT, fontSize:'0.8rem', color:SLATE_L }}>Type</span>
                                    <span style={{ fontFamily:FONT, fontSize:'0.85rem', fontWeight:600, color:getTypeColor(apt.type) }}>{apt.type}</span>
                                </div>

                                {/* Actions */}
                                <div style={{ display:'flex', gap:8 }}>
                                    <button 
                                        onClick={() => navigate(`/appointments/${apt.id}`)}
                                        style={{ 
                                            flex:1, padding:'10px 16px', borderRadius:10, border:`1px solid ${BORDER}`,
                                            background:WHITE, color:SLATE, fontFamily:FONT, fontSize:'0.85rem',
                                            fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center',
                                            justifyContent:'center', gap:6, transition:'all 0.2s'
                                        }}
                                        onMouseEnter={e => { e.currentTarget.style.background = SMOKE; e.currentTarget.style.borderColor = RED; }}
                                        onMouseLeave={e => { e.currentTarget.style.background = WHITE; e.currentTarget.style.borderColor = BORDER; }}
                                    >
                                        <FaEye /> View
                                    </button>
                                    <button 
                                        onClick={() => handleDelete(apt.id)}
                                        style={{ 
                                            padding:'10px 16px', borderRadius:10, border:`1px solid ${BORDER}`,
                                            background:WHITE, color:SLATE, fontFamily:FONT, fontSize:'0.85rem',
                                            fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center',
                                            justifyContent:'center', gap:6, transition:'all 0.2s'
                                        }}
                                        onMouseEnter={e => { e.currentTarget.style.background = '#FEE2E2'; e.currentTarget.style.borderColor = RED; e.currentTarget.style.color = RED; }}
                                        onMouseLeave={e => { e.currentTarget.style.background = WHITE; e.currentTarget.style.borderColor = BORDER; e.currentTarget.style.color = SLATE; }}
                                    >
                                        <FaCircleXmark />
                                    </button>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div style={{ gridColumn:'1/-1', textAlign:'center', padding:60, color:SLATE_L }}>
                            <FaCalendarDays style={{ fontSize:'3rem', marginBottom:16, opacity:0.5 }} />
                            <p style={{ fontSize:'1.1rem', fontWeight:600 }}>No appointments found</p>
                            <p style={{ fontSize:'0.9rem' }}>Try adjusting your search or filters</p>
                        </div>
                    )}
                </div>
            </div>
        </DashboardLayout>
    );
}

export default Appointments;
