import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaChartBar, FaChartLine, FaDroplet, FaUsers } from 'react-icons/fa6';
import './Analytics.css';

function Analytics() {
  const navigate = useNavigate();

  return (
    <div className="analytics-page">
      <div className="page-header">
        <div className="page-title-section">
          <div className="page-icon"><FaChartBar /></div>
          <div><h1>Analytics Dashboard</h1><p>View system analytics and insights</p></div>
        </div>
      </div>

      <div className="analytics-overview">
        <div className="analytics-card">
          <div className="analytics-icon"><FaDroplet /></div>
          <div className="analytics-info">
            <h3>Blood Usage</h3>
            <p>+12% this month</p>
          </div>
        </div>
        <div className="analytics-card">
          <div className="analytics-icon"><FaUsers /></div>
          <div className="analytics-info">
            <h3>Patient Growth</h3>
            <p>+8% this month</p>
          </div>
        </div>
        <div className="analytics-card">
          <div className="analytics-icon"><FaChartLine /></div>
          <div className="analytics-info">
            <h3>Donations</h3>
            <p>+15% this month</p>
          </div>
        </div>
      </div>

      <div className="analytics-grid">
        <div className="analytics-section">
          <h2>Blood Demand Prediction</h2>
          <div className="chart-container">
            <button className="btn-primary" onClick={() => navigate('/analytics/prediction')}>
              View Detailed Prediction
            </button>
          </div>
        </div>

        <div className="analytics-section">
          <h2>Interactive Charts</h2>
          <div className="chart-container">
            <button className="btn-primary" onClick={() => navigate('/analytics/charts')}>
              View Charts
            </button>
          </div>
        </div>

        <div className="analytics-section">
          <h2>Monthly Trends</h2>
          <div className="chart-placeholder">
            <p>Trend analysis chart</p>
          </div>
        </div>

        <div className="analytics-section">
          <h2>Performance Metrics</h2>
          <div className="chart-placeholder">
            <p>Performance metrics</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Analytics;