import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
    FaDroplet,
    FaHeartPulse,
    FaClock,
    FaHandHoldingMedical,
    FaLocationDot,
    FaPhone,
    FaCircleInfo,
    FaCircleCheck,
    FaMagnifyingGlass,
} from "react-icons/fa6";
import DashboardLayout from '../../components/DashboardLayout';
import { BloodBadge, StatusPill } from '../../components/DashboardLayout';

/* Design Tokens matching Dashboard */
const FONT = "'Inter','Segoe UI',system-ui,sans-serif";
const RED = "#C41230";
const RED_DK = "#8B0000";
const RED_GL = "rgba(196,18,48,0.12)";
const NAVY = "#0F172A";
const NAVY2 = "#1E293B";
const SLATE = "#334155";
const SLATE_L = "#64748B";
const BORDER = "#E2E8F0";
const SMOKE = "#F8FAFC";
const WHITE = "#FFFFFF";

const BG_COLOR = { "A+":"#16A34A","A-":"#15803D","B+":"#2563EB","B-":"#1D4ED8","AB+":"#7C3AED","AB-":"#6D28D9","O+":RED,"O-":RED_DK };

// Sample static data for our interactive operations
const LOCAL_BLOOD_STOCK = [
    { group: "A+", units: 120, status: "good", label: "Available" },
    { group: "A-", units: 45, status: "low", label: "Low Stock" },
    { group: "B+", units: 240, status: "good", label: "Available" },
    { group: "B-", units: 18, status: "low", label: "Low Stock" },
    { group: "AB+", units: 85, status: "good", label: "Available" },
    { group: "AB-", units: 12, status: "low", label: "Low Stock" },
    { group: "O+", units: 180, status: "good", label: "Available" },
    { group: "O-", units: 5, status: "critical", label: "Critical" },
];

const EMERGENCY_REQUESTS = [
    { id: "req-1", patientName: "Rahul Patel", group: "O-", units: 2, hospital: "Metro Cardiac Center", timeAgo: "2 mins ago", severity: "critical" },
    { id: "req-2", patientName: "Aanya Sharma", group: "AB-", units: 3, hospital: "Greenwood Pediatrics", timeAgo: "15 mins ago", severity: "high" },
    { id: "req-3", patientName: "Vikram Malhotra", group: "A-", units: 2, hospital: "Apex Trauma Care", timeAgo: "28 mins ago", severity: "medium" },
    { id: "req-4", patientName: "Priyanka Joshi", group: "B-", units: 1, hospital: "City General Hospital", timeAgo: "45 mins ago", severity: "medium" },
];

const BLOOD_BANKS_NETWORK = [
    {
        id: "bank-1",
        name: "Central Valley Blood Center",
        distance: "0.9 km",
        address: "410 Healthcare Blvd, Sector 4",
        phone: "+91 98765 43210",
        hours: "24/7 Operations",
        inventory: { "A+": 150, "A-": 12, "B+": 210, "B-": 5, "AB+": 80, "AB-": 4, "O+": 300, "O-": 8 },
    },
    {
        id: "bank-2",
        name: "Red Cross Donation Hub",
        distance: "2.4 km",
        address: "78 Red Cross Rd, Metro Colony",
        phone: "+91 98765 43211",
        hours: "08:00 AM - 08:00 PM",
        inventory: { "A+": 95, "A-": 8, "B+": 110, "B-": 4, "AB+": 45, "AB-": 2, "O+": 180, "O-": 3 },
    },
    {
        id: "bank-3",
        name: "Apex City Blood Bank",
        distance: "4.1 km",
        address: "12 Apex Towers, Ring Road",
        phone: "+91 98765 43212",
        hours: "24/7 Operations",
        inventory: { "A+": 240, "A-": 35, "B+": 190, "B-": 15, "AB+": 120, "AB-": 9, "O+": 410, "O-": 15 },
    },
    {
        id: "bank-4",
        name: "St. Jude Hospital Blood Bank",
        distance: "5.8 km",
        address: "502 St. Jude Lane, South Extension",
        phone: "+91 98765 43213",
        hours: "24/7 Operations",
        inventory: { "A+": 85, "A-": 3, "B+": 75, "B-": 1, "AB+": 20, "AB-": 0, "O+": 90, "O-": 0 },
    },
];

function BloodInventory() {
    const navigate = useNavigate();

    // Interactive operations states
    const [selectedRequest, setSelectedRequest] = useState(EMERGENCY_REQUESTS[0]);
    const [selectedBloodBank, setSelectedBloodBank] = useState(BLOOD_BANKS_NETWORK[0]);
    const [dispatchSuccess, setDispatchSuccess] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");

    const handleRequestSelect = (req) => {
        setSelectedRequest(req);
        const matchedBank = BLOOD_BANKS_NETWORK.find(bank => (bank.inventory[req.group] || 0) >= req.units) || BLOOD_BANKS_NETWORK[0];
        setSelectedBloodBank(matchedBank);
        setDispatchSuccess(false);
    };

    const handleDispatch = () => {
        setDispatchSuccess(true);
        setTimeout(() => {
            setDispatchSuccess(false);
        }, 4000);
    };

    const filteredStock = LOCAL_BLOOD_STOCK.filter(item =>
        item.group.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <DashboardLayout activeTab="blood-inventory" title="Blood Inventory Hub" subtitle="Live network coordination console for emergency stock routing">
            <div style={{ fontFamily:FONT }}>
                {/* Page Header with Search */}
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:28 }}>
                    <h2 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.5rem', color:SLATE, lineHeight:1.2 }}>Local Hospital Stock</h2>
                    <div style={{ display:'flex', alignItems:'center', gap:10, background:SMOKE, border:`1px solid ${BORDER}`, borderRadius:14, padding:'10px 16px', flex:1, maxWidth:400 }}>
                        <FaMagnifyingGlass style={{ color:SLATE_L, fontSize:'0.95rem' }} />
                        <input
                            type="text"
                            placeholder="Search blood group..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            style={{ border:'none', background:'transparent', fontFamily:FONT, fontSize:'0.9rem', color:SLATE, outline:'none', width:'100%' }}
                        />
                    </div>
                </div>

                <div style={{ display:'grid', gridTemplateColumns:'1fr 1.5fr', gap:24 }}>
                    {/* LEFT PANEL: Blood Stock Overview */}
                    <div>
                        <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:16, marginBottom:24 }}>
                            {filteredStock.map((item) => (
                                <div key={item.group} style={{
                                    background:WHITE, borderRadius:16, border:`1px solid ${BORDER}`,
                                    padding:20, boxShadow:'0 4px 16px rgba(0,0,0,0.06)',
                                    transition:'all 0.3s'
                                }}
                                    onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 12px 32px rgba(0,0,0,0.1)'; }}
                                    onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = '0 4px 16px rgba(0,0,0,0.06)'; }}
                                >
                                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                                        <div style={{ 
                                            width:48, height:48, borderRadius:12, 
                                            background:BG_COLOR[item.group]||RED,
                                            display:'flex', alignItems:'center', justifyContent:'center',
                                            color:WHITE, fontWeight:800, fontSize:'1.1rem',
                                            boxShadow:`0 8px 20px ${(BG_COLOR[item.group]||RED)}40`
                                        }}>
                                            {item.group}
                                        </div>
                                        <div style={{ 
                                            padding:'4px 10px', borderRadius:10, fontSize:'0.7rem', fontWeight:700,
                                            background:item.status === 'critical' ? `${RED}15` : item.status === 'low' ? '#D9770615' : '#16A34A15',
                                            color:item.status === 'critical' ? RED : item.status === 'low' ? '#D97706' : '#16A34A'
                                        }}>
                                            {item.label}
                                        </div>
                                    </div>
                                    <div style={{ marginBottom:8 }}>
                                        <h3 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.8rem', color:SLATE, lineHeight:1 }}>{item.units}</h3>
                                        <span style={{ fontFamily:FONT, fontSize:'0.8rem', color:SLATE_L }}>Units</span>
                                    </div>
                                    <div style={{ height:6, background:SMOKE, borderRadius:3, overflow:'hidden' }}>
                                        <div style={{ 
                                            height:'100%', 
                                            background:BG_COLOR[item.group]||RED, 
                                            width:`${Math.min((item.units/250)*100,100)}%`,
                                            borderRadius:3
                                        }} />
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Add Stock Button */}
                        <button 
                            onClick={() => navigate('/blood-inventory/add')}
                            style={{ 
                                width:'100%', padding:'16px', borderRadius:16, border:'none',
                                background:`linear-gradient(135deg,${RED},${RED_DK})`,
                                color:WHITE, fontFamily:FONT, fontSize:'1rem', fontWeight:700,
                                cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                                gap:10, boxShadow:`0 4px 16px ${RED_GL}`, transition:'all 0.3s'
                            }}
                            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = `0 8px 24px ${RED_GL}`; }}
                            onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = `0 4px 16px ${RED_GL}`; }}
                        >
                            <FaDroplet /> Add Blood Stock
                        </button>
                    </div>

                    {/* RIGHT PANEL: Emergency Dispatch */}
                    <div>
                        <div style={{ background:WHITE, borderRadius:20, border:`1px solid ${BORDER}`, padding:24, boxShadow:'0 4px 20px rgba(0,0,0,0.06)' }}>
                            <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:20 }}>
                                <div style={{ 
                                    width:48, height:48, borderRadius:12, 
                                    background:`${RED}15`, display:'flex', alignItems:'center', justifyContent:'center',
                                    color:RED, fontSize:'1.3rem'
                                }}>
                                    <FaHeartPulse />
                                </div>
                                <div>
                                    <h3 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.1rem', color:SLATE, marginBottom:2 }}>Emergency Dispatch</h3>
                                    <p style={{ fontFamily:FONT, fontSize:'0.85rem', color:SLATE_L }}>Critical blood request coordination</p>
                                </div>
                            </div>

                            {/* Emergency Requests List */}
                            <div style={{ marginBottom:20 }}>
                                <h4 style={{ fontFamily:FONT, fontWeight:700, fontSize:'0.9rem', color:SLATE, marginBottom:12 }}>Active Requests</h4>
                                <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                                    {EMERGENCY_REQUESTS.map((req) => (
                                        <div 
                                            key={req.id}
                                            onClick={() => handleRequestSelect(req)}
                                            style={{
                                                padding:'12px 16px', borderRadius:12, border:`1px solid ${BORDER}`,
                                                background:selectedRequest.id === req.id ? `${RED}08` : SMOKE,
                                                cursor:'pointer', transition:'all 0.2s',
                                                display:'flex', alignItems:'center', gap:12
                                            }}
                                            onMouseEnter={e => { if(selectedRequest.id !== req.id) e.currentTarget.style.background = BORDER; }}
                                            onMouseLeave={e => { if(selectedRequest.id !== req.id) e.currentTarget.style.background = SMOKE; }}
                                        >
                                            <BloodBadge group={req.group} />
                                            <div style={{ flex:1 }}>
                                                <div style={{ fontFamily:FONT, fontWeight:600, fontSize:'0.9rem', color:SLATE }}>{req.patientName}</div>
                                                <div style={{ fontFamily:FONT, fontSize:'0.8rem', color:SLATE_L }}>{req.hospital} • {req.timeAgo}</div>
                                            </div>
                                            <div style={{ 
                                                padding:'4px 8px', borderRadius:8, fontSize:'0.7rem', fontWeight:700,
                                                background:req.severity === 'critical' ? `${RED}15` : req.severity === 'high' ? '#D9770615' : '#16A34A15',
                                                color:req.severity === 'critical' ? RED : req.severity === 'high' ? '#D97706' : '#16A34A'
                                            }}>
                                                {req.severity}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Selected Request Details */}
                            <div style={{ padding:16, background:SMOKE, borderRadius:14, marginBottom:20 }}>
                                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                                    <div>
                                        <div style={{ fontFamily:FONT, fontSize:'0.8rem', color:SLATE_L, marginBottom:4 }}>Selected Request</div>
                                        <div style={{ fontFamily:FONT, fontWeight:700, fontSize:'1rem', color:SLATE }}>{selectedRequest.patientName}</div>
                                    </div>
                                    <BloodBadge group={selectedRequest.group} size="lg" />
                                </div>
                                <div style={{ display:'flex', gap:24, fontSize:'0.85rem', color:SLATE }}>
                                    <span><strong>{selectedRequest.units}</strong> units needed</span>
                                    <span>•</span>
                                    <span>{selectedRequest.hospital}</span>
                                </div>
                            </div>

                            {/* Blood Bank Selection */}
                            <div style={{ marginBottom:20 }}>
                                <h4 style={{ fontFamily:FONT, fontWeight:700, fontSize:'0.9rem', color:SLATE, marginBottom:12 }}>Available Blood Banks</h4>
                                <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                                    {BLOOD_BANKS_NETWORK.map((bank) => (
                                        <div 
                                            key={bank.id}
                                            onClick={() => setSelectedBloodBank(bank)}
                                            style={{
                                                padding:'12px 16px', borderRadius:12, border:`1px solid ${BORDER}`,
                                                background:selectedBloodBank.id === bank.id ? `${RED}08` : SMOKE,
                                                cursor:'pointer', transition:'all 0.2s'
                                            }}
                                            onMouseEnter={e => { if(selectedBloodBank.id !== bank.id) e.currentTarget.style.background = BORDER; }}
                                            onMouseLeave={e => { if(selectedBloodBank.id !== bank.id) e.currentTarget.style.background = SMOKE; }}
                                        >
                                            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
                                                <div style={{ fontFamily:FONT, fontWeight:600, fontSize:'0.9rem', color:SLATE }}>{bank.name}</div>
                                                <div style={{ fontFamily:FONT, fontSize:'0.8rem', color:SLATE_L }}>{bank.distance}</div>
                                            </div>
                                            <div style={{ display:'flex', gap:12, fontSize:'0.8rem', color:SLATE }}>
                                                <span>{bank.inventory[selectedRequest.group] || 0} units {selectedRequest.group}</span>
                                                <span>•</span>
                                                <span>{bank.hours}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Dispatch Button */}
                            {dispatchSuccess ? (
                                <div style={{ 
                                    padding:'16px', borderRadius:12, background:'#DCFCE7', border:'1px solid #16A34A',
                                    display:'flex', alignItems:'center', gap:12, color:'#16A34A'
                                }}>
                                    <FaCircleCheck style={{ fontSize:'1.5rem' }} />
                                    <div>
                                        <div style={{ fontFamily:FONT, fontWeight:700, fontSize:'0.95rem' }}>Dispatch Successful!</div>
                                        <div style={{ fontFamily:FONT, fontSize:'0.85rem' }}>Blood units are on the way to {selectedRequest.hospital}</div>
                                    </div>
                                </div>
                            ) : (
                                <button 
                                    onClick={handleDispatch}
                                    style={{ 
                                        width:'100%', padding:'16px', borderRadius:12, border:'none',
                                        background:`linear-gradient(135deg,${RED},${RED_DK})`,
                                        color:WHITE, fontFamily:FONT, fontSize:'1rem', fontWeight:700,
                                        cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                                        gap:10, boxShadow:`0 4px 16px ${RED_GL}`, transition:'all 0.3s'
                                    }}
                                    onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = `0 8px 24px ${RED_GL}`; }}
                                    onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = `0 4px 16px ${RED_GL}`; }}
                                >
                                    <FaHeartPulse /> Dispatch Blood Units
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}

export default BloodInventory;
