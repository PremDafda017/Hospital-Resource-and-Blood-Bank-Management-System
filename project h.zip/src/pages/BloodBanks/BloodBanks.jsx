import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaBuilding,
  FaPlus,
  FaMagnifyingGlass,
  FaLocationDot,
  FaPhone,
  FaEnvelope,
  FaClock,
  FaEye,
  FaPencil
} from 'react-icons/fa6';
import DashboardLayout from '../../components/DashboardLayout';
import { StatusPill } from '../../components/DashboardLayout';

/* Design Tokens matching Dashboard */
const FONT = "'Inter','Segoe UI',system-ui,sans-serif";
const RED = "#C41230";
const RED_DK = "#8B0000";
const RED_GL = "rgba(196,18,48,0.12)";
const NAVY = "#0F172A";
const NAVY2 = "#1E293B";
const SLATE = "#334155";
const SLATE_L = "#64748B";
const BORDER = "#E2E8F0";
const SMOKE = "#F8FAFC";
const WHITE = "#FFFFFF";

function BloodBanks() {
  const navigate = useNavigate();
  const [bloodBanks, setBloodBanks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchBloodBanks();
  }, []);

  const fetchBloodBanks = async () => {
    try {
      const mockBloodBanks = [
        {
          id: 1,
          name: 'Central Blood Bank',
          address: '123 Medical Center Dr',
          city: 'New York',
          phone: '555-0401',
          email: 'central@bloodbank.com',
          hours: '24/7',
          totalStock: 150,
          status: 'Active'
        },
        {
          id: 2,
          name: 'Riverside Blood Center',
          address: '456 River Road',
          city: 'Brooklyn',
          phone: '555-0402',
          email: 'riverside@bloodbank.com',
          hours: '8 AM - 8 PM',
          totalStock: 85,
          status: 'Active'
        }
      ];
      
      setTimeout(() => {
        setBloodBanks(mockBloodBanks);
        setLoading(false);
      }, 500);
    } catch (error) {
      console.error('Error fetching blood banks:', error);
      setLoading(false);
    }
  };

  const filteredBloodBanks = bloodBanks.filter(bank =>
    bank.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bank.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <DashboardLayout activeTab="hospitals" title="Blood Banks" subtitle="Manage blood bank locations and inventory">
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', minHeight:300, gap:12 }}>
          <div style={{ width:48, height:48, borderRadius:'50%', border:`3px solid ${BORDER}`, borderTopColor:RED, animation:'spin 0.9s linear infinite' }} />
          <style>{"@keyframes spin{to{transform:rotate(360deg)}}"}</style>
          <p style={{ color:SLATE_L, fontWeight:600 }}>Loading blood banks...</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout activeTab="hospitals" title="Blood Banks" subtitle="Manage blood bank locations and inventory">
      <div style={{ fontFamily:FONT }}>
        {/* Page Header */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:28 }}>
          <h2 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.5rem', color:SLATE, lineHeight:1.2 }}>Blood Bank Registry</h2>
          <button 
            onClick={() => navigate('/blood-banks/add')}
            style={{ 
              background:`linear-gradient(135deg,${RED},${RED_DK})`,
              color:WHITE, border:'none', borderRadius:12, padding:'12px 24px',
              fontFamily:FONT, fontSize:'0.9rem', fontWeight:700, cursor:'pointer',
              display:'flex', alignItems:'center', gap:8,
              boxShadow:`0 4px 16px ${RED_GL}`,
              transition:'all 0.25s'
            }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = `0 8px 24px ${RED_GL}`; }}
            onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = `0 4px 16px ${RED_GL}`; }}
          >
            <FaPlus /> Add Blood Bank
          </button>
        </div>

        {/* Filters */}
        <div style={{ display:'flex', gap:16, marginBottom:28 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10, background:SMOKE, border:`1px solid ${BORDER}`, borderRadius:14, padding:'10px 16px', flex:1, maxWidth:400 }}>
            <FaMagnifyingGlass style={{ color:SLATE_L, fontSize:'0.95rem' }} />
            <input
              type="text"
              placeholder="Search blood banks..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ border:'none', background:'transparent', fontFamily:FONT, fontSize:'0.9rem', color:SLATE, outline:'none', width:'100%' }}
            />
          </div>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(340px,1fr))', gap:20 }}>
          {filteredBloodBanks.length > 0 ? (
            filteredBloodBanks.map(bank => (
              <div key={bank.id} style={{
                background:WHITE, borderRadius:20, border:`1px solid ${BORDER}`,
                padding:24, boxShadow:'0 4px 20px rgba(0,0,0,0.06)',
                transition:'all 0.3s'
              }}
                onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = '0 20px 60px rgba(0,0,0,0.12)'; }}
                onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = '0 4px 20px rgba(0,0,0,0.06)'; }}
              >
                {/* Header */}
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
                  <div style={{ 
                    width:56, height:56, borderRadius:16, 
                    background:`linear-gradient(135deg,${RED},${RED_DK})`,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    color:WHITE, fontSize:'1.4rem'
                  }}>
                    <FaBuilding />
                  </div>
                  <StatusPill status={bank.status} />
                </div>

                {/* Info */}
                <div style={{ marginBottom:16 }}>
                  <h3 style={{ fontFamily:FONT, fontWeight:800, fontSize:'1.1rem', color:SLATE, lineHeight:1.2, marginBottom:8 }}>{bank.name}</h3>
                  <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'0.85rem', color:SLATE, marginBottom:4 }}>
                    <FaLocationDot style={{ color:SLATE_L, fontSize:'0.9rem' }} />
                    <span>{bank.address}, {bank.city}</span>
                  </div>
                  <div style={{ display:'flex', gap:16, fontSize:'0.85rem', color:SLATE }}>
                    <span style={{ display:'flex', alignItems:'center', gap:6 }}><FaClock style={{ color:SLATE_L }} /> {bank.hours}</span>
                    <span style={{ display:'flex', alignItems:'center', gap:6 }}>Stock: {bank.totalStock} units</span>
                  </div>
                </div>

                {/* Details */}
                <div style={{ display:'flex', flexDirection:'column', gap:8, marginBottom:16, padding:'16px', background:SMOKE, borderRadius:14 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'0.85rem', color:SLATE }}>
                    <FaPhone style={{ color:SLATE_L, fontSize:'0.9rem' }} />
                    <span>{bank.phone}</span>
                  </div>
                  <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'0.85rem', color:SLATE }}>
                    <FaEnvelope style={{ color:SLATE_L, fontSize:'0.9rem' }} />
                    <span>{bank.email}</span>
                  </div>
                </div>

                {/* Actions */}
                <div style={{ display:'flex', gap:8 }}>
                  <button 
                    onClick={() => navigate(`/blood-banks/${bank.id}`)}
                    style={{ 
                      flex:1, padding:'10px 16px', borderRadius:10, border:`1px solid ${BORDER}`,
                      background:WHITE, color:SLATE, fontFamily:FONT, fontSize:'0.85rem',
                      fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center',
                      justifyContent:'center', gap:6, transition:'all 0.2s'
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = SMOKE; e.currentTarget.style.borderColor = RED; }}
                    onMouseLeave={e => { e.currentTarget.style.background = WHITE; e.currentTarget.style.borderColor = BORDER; }}
                  >
                    <FaEye /> View
                  </button>
                  <button 
                    onClick={() => navigate(`/blood-banks/${bank.id}/edit`)}
                    style={{ 
                      padding:'10px 16px', borderRadius:10, border:`1px solid ${BORDER}`,
                      background:WHITE, color:SLATE, fontFamily:FONT, fontSize:'0.85rem',
                      fontWeight:600, cursor:'pointer', display:'flex', alignItems:'center',
                      justifyContent:'center', gap:6, transition:'all 0.2s'
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = SMOKE; e.currentTarget.style.borderColor = RED; }}
                    onMouseLeave={e => { e.currentTarget.style.background = WHITE; e.currentTarget.style.borderColor = BORDER; }}
                  >
                    <FaPencil />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div style={{ gridColumn:'1/-1', textAlign:'center', padding:60, color:SLATE_L }}>
              <FaBuilding style={{ fontSize:'3rem', marginBottom:16, opacity:0.5 }} />
              <p style={{ fontSize:'1.1rem', fontWeight:600 }}>No blood banks found</p>
              <p style={{ fontSize:'0.9rem' }}>Try adjusting your search</p>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

export default BloodBanks;
